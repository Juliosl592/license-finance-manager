import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Link } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import Navbar from "@/components/navbar";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useQuery } from "@tanstack/react-query";
import { Query } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronDown, File, FileText, Loader2 } from "lucide-react";

const passwordSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^A-Za-z0-9]/, "Password must contain at least one special character"),
  confirmNewPassword: z.string().min(1, "Please confirm your new password"),
}).refine((data) => data.newPassword === data.confirmNewPassword, {
  message: "Passwords don't match",
  path: ["confirmNewPassword"],
});

type PasswordFormValues = z.infer<typeof passwordSchema>;

export default function UserDashboard() {
  const { user } = useAuth();
  const [passwordChangeSuccess, setPasswordChangeSuccess] = useState(false);

  const { data: licenseQueries, isLoading } = useQuery<Query[]>({
    queryKey: ["/api/queries/user"],
    enabled: !!user,
  });

  const form = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmNewPassword: "",
    },
  });

  function onSubmit(values: PasswordFormValues) {
    console.log("Password change values:", values);
    setPasswordChangeSuccess(true);
    form.reset();
    setTimeout(() => {
      setPasswordChangeSuccess(false);
    }, 5000);
  }

  if (!user) return null;

  const lastLoginFormatted = user.lastLogin 
    ? format(new Date(user.lastLogin), "MMMM d, yyyy 'at' h:mm a")
    : "N/A";

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">User Profile</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => window.history.back()}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Atrás
          </Button>

          <Link href="/">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              Inicio
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Profile Information</CardTitle>
          <CardDescription>Personal details and application settings</CardDescription>
        </CardHeader>
        <CardContent>
          <dl className="divide-y divide-gray-200">
            <div className="grid grid-cols-3 gap-4 py-3">
              <dt className="text-sm font-medium text-gray-500">Full name</dt>
              <dd className="text-sm text-gray-900 col-span-2">{user.firstName} {user.lastName}</dd>
            </div>

            <div className="grid grid-cols-3 gap-4 py-3">
              <dt className="text-sm font-medium text-gray-500">Username</dt>
              <dd className="text-sm text-gray-900 col-span-2">{user.username}</dd>
            </div>

            <div className="grid grid-cols-3 gap-4 py-3">
              <dt className="text-sm font-medium text-gray-500">Email address</dt>
              <dd className="text-sm text-gray-900 col-span-2">{user.email}</dd>
            </div>

            <div className="grid grid-cols-3 gap-4 py-3">
              <dt className="text-sm font-medium text-gray-500">Account role</dt>
              <dd className="text-sm text-gray-900 col-span-2 capitalize">{user.role}</dd>
            </div>

            <div className="grid grid-cols-3 gap-4 py-3">
              <dt className="text-sm font-medium text-gray-500">Last login</dt>
              <dd className="text-sm text-gray-900 col-span-2">{lastLoginFormatted}</dd>
            </div>
          </dl>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Change Password</CardTitle>
          <CardDescription>Update your password to keep your account secure</CardDescription>
        </CardHeader>
        <CardContent>
          {passwordChangeSuccess && (
            <Alert className="mb-4 bg-green-50 text-green-700">
              <AlertDescription>
                Your password has been updated successfully.
              </AlertDescription>
            </Alert>
          )}

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 max-w-md">
              <FormField
                control={form.control}
                name="currentPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Enter your current password" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="newPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Enter your new password" {...field} />
                    </FormControl>
                    <FormDescription>
                      Password must be at least 8 characters and include uppercase, lowercase, number, and special character
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmNewPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm New Password</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="Confirm your new password" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit">Update Password</Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Historial de Cálculos de Licencias</CardTitle>
          <CardDescription>Revisa tus consultas de licencias más recientes</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : !licenseQueries || licenseQueries.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              <FileText className="h-12 w-12 mx-auto mb-2 opacity-30" />
              <p>No has realizado ninguna consulta de licencias todavía.</p>
              <p className="mt-2">
                <Link href="/license-query">
                  <Button variant="outline" className="mt-2">
                    Realizar una consulta
                  </Button>
                </Link>
              </p>
            </div>
          ) : (
            <Table>
              <TableCaption>Lista de consultas de licencias realizadas</TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Cantidad</TableHead>
                  <TableHead>Precio</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {licenseQueries.map((query) => (
                  <TableRow key={query.id}>
                    <TableCell>
                      {query.createdAt ? format(new Date(query.createdAt), "dd/MM/yyyy HH:mm") : "N/A"}
                    </TableCell>
                    <TableCell>{(query.parameters as any)?.licenseQuantity || "N/A"}</TableCell>
                    <TableCell>${((query.parameters as any)?.licenseUnitPrice || 0).toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        ${(((query.parameters as any)?.licenseQuantity || 0) * ((query.parameters as any)?.licenseUnitPrice || 0)).toLocaleString()}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Link href={`/licenses/results/${query.id}`}>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <span className="sr-only">Ver detalle</span>
                          <File className="h-4 w-4" />
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      
    </div>
  );
}