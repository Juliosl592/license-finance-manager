import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, FileSpreadsheet, FileDown, Trash } from "lucide-react";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";

// Schema para validar el formulario de consulta
const queryFormSchema = z.object({
  queryType: z.string({ required_error: "Seleccione un tipo de consulta" }),
  monto: z.string().min(1, "El monto es requerido")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "El monto debe ser un número positivo"),
  plazoMeses: z.string().min(1, "El plazo es requerido")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "El plazo debe ser un número entero positivo"),
  tasaInteres: z.string().min(1, "La tasa de interés es requerida")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "La tasa debe ser un número positivo"),
  tipo: z.enum(["simple", "compuesto"])
});

type QueryFormValues = z.infer<typeof queryFormSchema>;

export default function QueryPage() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("query");
  
  // Formulario para realizar consultas
  const form = useForm<QueryFormValues>({
    resolver: zodResolver(queryFormSchema),
    defaultValues: {
      queryType: "",
      monto: "",
      plazoMeses: "",
      tasaInteres: "",
      tipo: "simple"
    }
  });
  
  // Obtener las consultas recientes del usuario
  const { data: recentQueries, isLoading: loadingQueries } = useQuery({
    queryKey: ["/api/queries"],
    enabled: !!user
  });
  
  // Obtener conceptos para el tipo de consulta
  const { data: concepts, isLoading: loadingConcepts } = useQuery({
    queryKey: ["/api/concepts"],
    enabled: !!user
  });
  
  // Obtener tasas de interés disponibles
  const { data: interestRates, isLoading: loadingRates } = useQuery({
    queryKey: ["/api/interest-rates"],
    enabled: !!user
  });
  
  // Obtener plazos disponibles
  const { data: terms, isLoading: loadingTerms } = useQuery({
    queryKey: ["/api/terms"],
    enabled: !!user
  });
  
  // Mutación para crear una consulta
  const createQueryMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/queries", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/queries"]
      });
      setActiveTab("history");
    }
  });
  
  // Mutación para eliminar una consulta
  const deleteQueryMutation = useMutation({
    mutationFn: async (queryId: number) => {
      await apiRequest("DELETE", `/api/queries/${queryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/queries"]
      });
    }
  });
  
  // Manejar envío del formulario
  function onSubmit(values: QueryFormValues) {
    const queryData = {
      queryType: values.queryType,
      parameters: {
        monto: values.monto,
        plazoMeses: values.plazoMeses,
        tasaInteres: values.tasaInteres,
        tipo: values.tipo
      }
    };
    
    createQueryMutation.mutate(queryData);
  }
  
  // Formatear número a moneda
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: 'MXN'
    }).format(amount);
  };
  
  // Generar Excel (función simulada)
  const generateExcel = (query: any) => {
    console.log("Generando Excel para", query);
    alert("Exportación a Excel iniciada. El archivo se descargará pronto.");
  };
  
  // Generar PDF (función simulada)
  const generatePDF = (query: any) => {
    console.log("Generando PDF para", query);
    alert("Exportación a PDF iniciada. El archivo se descargará pronto.");
  };
  
  // Manejar eliminación de consulta
  const handleDeleteQuery = (id: number) => {
    if (confirm("¿Está seguro de que desea eliminar esta consulta?")) {
      deleteQueryMutation.mutate(id);
    }
  };
  
  // Renderizar tabla de resultados de consulta
  const renderQueryResultsTable = (query: any) => {
    if (!query.results) return null;
    
    const results = query.results;
    const detalles = results.detalles || [];
    
    return (
      <div className="space-y-4 mt-4">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm font-medium text-gray-500">Monto Inicial</div>
              <div className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(results.montoInicial)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm font-medium text-gray-500">Interés Total</div>
              <div className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(results.interes)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm font-medium text-gray-500">Monto Final</div>
              <div className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(results.montoTotal)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="text-sm font-medium text-gray-500">Pago Mensual</div>
              <div className="mt-2 text-2xl font-semibold text-gray-900">
                {formatCurrency(results.pagoMensual)}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Tabla de Amortización</CardTitle>
            <CardDescription>Detalles mensuales de pagos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Mes</TableHead>
                    <TableHead>Pago Capital</TableHead>
                    <TableHead>Pago Interés</TableHead>
                    <TableHead>Pago Total</TableHead>
                    <TableHead>Saldo Restante</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detalles.map((detalle: any) => (
                    <TableRow key={detalle.mes}>
                      <TableCell>{detalle.mes}</TableCell>
                      <TableCell>{formatCurrency(detalle.pagoCapital)}</TableCell>
                      <TableCell>{formatCurrency(detalle.pagoInteres)}</TableCell>
                      <TableCell>{formatCurrency(detalle.pagoTotal)}</TableCell>
                      <TableCell>{formatCurrency(detalle.saldoRestante)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => generateExcel(query)}>
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Exportar a Excel
            </Button>
            <Button onClick={() => generatePDF(query)}>
              <FileDown className="mr-2 h-4 w-4" />
              Generar PDF
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  };
  
  if (!user) return null;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Cálculo Financiero</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => window.history.back()}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Atrás
          </Button>
          
          <Link href="/">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              Inicio
            </Button>
          </Link>
        </div>
      </div>
      
      <Tabs defaultValue="query" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="query">Nueva Consulta</TabsTrigger>
          <TabsTrigger value="history">Historial de Consultas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="query" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Realizar Nueva Consulta</CardTitle>
              <CardDescription>Calcule valores financieros usando diferentes parámetros</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="queryType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo de Consulta</FormLabel>
                        <Select
                          value={field.value}
                          onValueChange={field.onChange}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Seleccione un tipo de consulta" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {loadingConcepts ? (
                              <div className="flex items-center justify-center py-2">
                                <Loader2 className="h-4 w-4 animate-spin" />
                              </div>
                            ) : concepts && concepts.length > 0 ? (
                              concepts.map((concept: any) => (
                                <SelectItem key={concept.id} value={concept.name}>
                                  {concept.name}
                                </SelectItem>
                              ))
                            ) : (
                              <SelectItem disabled value="no-concepts">
                                No hay conceptos disponibles
                              </SelectItem>
                            )}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="monto"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Monto</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Ingrese el monto"
                              type="number"
                              min="0"
                              step="0.01"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription>
                            Monto inicial para el cálculo
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="plazoMeses"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Plazo (meses)</FormLabel>
                          <Select
                            value={field.value.toString()}
                            onValueChange={field.onChange}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione un plazo" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {loadingTerms ? (
                                <div className="flex items-center justify-center py-2">
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                </div>
                              ) : terms && terms.length > 0 ? (
                                terms.map((term: any) => (
                                  <SelectItem key={term.id} value={term.months.toString()}>
                                    {term.name} ({term.months} meses)
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem disabled value="no-terms">
                                  No hay plazos disponibles
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Duración en meses
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="tasaInteres"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tasa de Interés (%)</FormLabel>
                          <Select
                            value={field.value.toString()}
                            onValueChange={field.onChange}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione una tasa" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {loadingRates ? (
                                <div className="flex items-center justify-center py-2">
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                </div>
                              ) : interestRates && interestRates.length > 0 ? (
                                interestRates.map((rate: any) => (
                                  <SelectItem key={rate.id} value={rate.rate.toString()}>
                                    {rate.name} ({rate.rate}%)
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem disabled value="no-rates">
                                  No hay tasas disponibles
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Tasa de interés anual
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="tipo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo de Interés</FormLabel>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Seleccione tipo de interés" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="simple">Interés Simple</SelectItem>
                              <SelectItem value="compuesto">Interés Compuesto</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            Método de cálculo de interés
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full md:w-auto"
                    disabled={createQueryMutation.isPending}
                  >
                    {createQueryMutation.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    Calcular
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Historial de Consultas</CardTitle>
              <CardDescription>Sus últimas 5 consultas realizadas</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingQueries ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : !recentQueries || recentQueries.length === 0 ? (
                <Alert>
                  <AlertTitle>Sin consultas previas</AlertTitle>
                  <AlertDescription>
                    No ha realizado ninguna consulta todavía. Vaya a la pestaña "Nueva Consulta" para realizar su primer cálculo.
                  </AlertDescription>
                </Alert>
              ) : (
                <div className="space-y-6">
                  {recentQueries.map((query: any) => (
                    <Card key={query.id} className="overflow-hidden">
                      <CardHeader className="bg-muted/50">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="flex items-center">
                              {query.queryType}
                              <Badge variant="outline" className="ml-2">
                                {query.parameters.tipo === "simple" ? "Interés Simple" : "Interés Compuesto"}
                              </Badge>
                            </CardTitle>
                            <CardDescription>
                              Realizada el {format(new Date(query.createdAt), "dd/MM/yyyy 'a las' HH:mm")}
                            </CardDescription>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => handleDeleteQuery(query.id)}
                            disabled={deleteQueryMutation.isPending}
                          >
                            {deleteQueryMutation.isPending ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <Trash className="h-4 w-4 text-red-500" />
                            )}
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-3 gap-4 mb-4">
                          <div>
                            <span className="text-sm font-medium text-gray-500 block">Monto:</span>
                            <span className="text-lg font-semibold">
                              {formatCurrency(parseFloat(query.parameters.monto))}
                            </span>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-gray-500 block">Plazo:</span>
                            <span className="text-lg font-semibold">
                              {query.parameters.plazoMeses} meses
                            </span>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-gray-500 block">Tasa:</span>
                            <span className="text-lg font-semibold">
                              {query.parameters.tasaInteres}%
                            </span>
                          </div>
                        </div>
                        
                        {renderQueryResultsTable(query)}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}