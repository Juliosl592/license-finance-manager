import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/navbar";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Calculator, Users, UserCircle, History, SquareStack, Database, Settings } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  // Obtener las estadísticas para mostrar
  const { data: conceptsCount } = useQuery({
    queryKey: ["/api/concepts/count"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/concepts");
        const data = await res.json();
        return data.length || 0;
      } catch (error) {
        console.error("Error fetching concepts count:", error);
        return 0;
      }
    },
    enabled: !!user
  });
  
  const { data: recentQueries } = useQuery({
    queryKey: ["/api/queries"],
    enabled: !!user && user.role !== "admin"
  });
  
  const isAdmin = user?.role === "admin";
  
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Bienvenido{user ? `, ${user.firstName}` : ""}
          </h1>
          <p className="text-lg text-gray-600">
            {isAdmin 
              ? "Gestione usuarios, tasas, plazos y conceptos para su aplicación" 
              : "Realice consultas financieras y acceda a su historial"}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {isAdmin ? (
            // Tarjetas para administrador
            <>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-xl font-bold">Gestión de Usuarios</CardTitle>
                  <Users className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">
                    Administre los usuarios del sistema, cambie roles y permisos.
                  </CardDescription>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <Link href="/admin">Ir a Usuarios</Link>
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-xl font-bold">Gestión de Tasas</CardTitle>
                  <Calculator className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">
                    Administre las tasas de interés disponibles para las consultas.
                  </CardDescription>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" disabled>
                    Próximamente
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-xl font-bold">Reportes</CardTitle>
                  <History className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">
                    Acceda a reportes históricos y estadísticas de uso.
                  </CardDescription>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" disabled>
                    Próximamente
                  </Button>
                </CardFooter>
              </Card>
            </>
          ) : (
            // Tarjetas para usuario regular
            <>
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-xl font-bold text-blue-800">Consulta de Licencias</CardTitle>
                  <SquareStack className="w-6 h-6 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm text-blue-700">
                    Calcule costos de licencias con financiamiento y bolsas de horas.
                  </CardDescription>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="default" className="bg-blue-600 hover:bg-blue-700">
                    <Link href="/license-query">Calcular licencias</Link>
                  </Button>
                </CardFooter>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
                  <CardTitle className="text-xl font-bold">Historial</CardTitle>
                  <History className="w-6 h-6 text-primary" />
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">
                    {recentQueries && recentQueries.length > 0 
                      ? `Tiene ${recentQueries.length} consultas recientes guardadas.`
                      : "No hay consultas recientes en su historial."
                    }
                  </CardDescription>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline">
                    <Link href="/user">Ver historial</Link>
                  </Button>
                </CardFooter>
              </Card>
            </>
          )}
        </div>
        

      </div>
      
      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 overflow-hidden sm:px-6 lg:px-8">
          <p className="text-center text-base text-gray-500">
            &copy; {new Date().getFullYear()} Calculadora Financiera. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}
