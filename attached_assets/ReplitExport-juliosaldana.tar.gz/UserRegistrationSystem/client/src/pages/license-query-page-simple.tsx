import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Loader2 } from "lucide-react";

// Components
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Schema para validar el formulario de licencias
const licenseQuerySchema = z.object({
  licenseQuantity: z.string()
    .min(1, "La cantidad de licencias es requerida")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "Debe ser un número entero positivo"),
  licenseUnitPrice: z.string()
    .min(1, "El precio unitario es requerido")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "Debe ser un número positivo"),
});

type LicenseQueryFormValues = z.infer<typeof licenseQuerySchema>;

export default function LicenseQueryPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [queryResults, setQueryResults] = useState<any>(null);
  const [selectedOptions, setSelectedOptions] = useState({
    licenses: "",
    hourPackage: "",
    implementation: ""
  });
  const [showSummary, setShowSummary] = useState(true);

  // Form
  const form = useForm({
    resolver: zodResolver(licenseQuerySchema),
    defaultValues: {
      licenseQuantity: "",
      licenseUnitPrice: "",
    }
  });

  // Obtener plazos
  const { data: terms } = useQuery({
    queryKey: ["/api/terms"],
    enabled: !!user
  });

  // Mutación para crear consulta
  const createQueryMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/license-query", data);
      return await res.json();
    },
    onSuccess: (data) => {
      setQueryResults(data);
      queryClient.invalidateQueries({
        queryKey: ["/api/queries"]
      });
      toast({
        title: "Consulta realizada",
        description: "Los resultados de su consulta están listos.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "No se pudo realizar la consulta. Revise los datos e intente nuevamente.",
        variant: "destructive"
      });
    }
  });

  // Manejar envío del formulario
  function onSubmit(values: any) {
    createQueryMutation.mutate({
      queryType: "license-calculation",
      parameters: values
    });
  }

  // Formatear número a moneda
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: 'MXN'
    }).format(amount);
  };

  // Manejar selección de opciones de pago
  const handlePaymentOptionChange = (concept: string, value: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [concept]: prev[concept] === value ? "" : value,
      implementation: concept === "implementation" ? value : prev.implementation
    }));
  };

  // Calcular total según opciones seleccionadas
  const calculateSelectedTotal = () => {
    if (!queryResults) return { totalAmount: 0, monthlyPayment: 0, details: [] };

    let totalAmount = 0;
    let monthlyPayment = 0;
    const details: any[] = [];

    // Licencias
    if (selectedOptions.licenses === "cash") {
      totalAmount += queryResults.totalLicenseCost;
      details.push({
        concept: "Licencias",
        paymentType: "Contado",
        amount: queryResults.totalLicenseCost,
        monthlyPayment: 0
      });
    } else if (selectedOptions.licenses) {
      const termOption = queryResults.financingOptions.find(
        (opt: any) => opt.termId.toString() === selectedOptions.licenses && opt.concept === "Licencias"
      );
      if (termOption) {
        totalAmount += termOption.totalAmount;
        monthlyPayment += termOption.monthlyPayment;
        details.push({
          concept: "Licencias",
          paymentType: `Financiado ${termOption.term.name}`,
          amount: termOption.totalAmount,
          monthlyPayment: termOption.monthlyPayment
        });
      }
    }

    // Bolsa de Horas
    if (selectedOptions.hourPackage) {
      const [termId, hoursType] = selectedOptions.hourPackage.split('-');
      let baseAmount = 0;
      switch(hoursType) {
        case '30h': baseAmount = 500000; break;
        case '70h': baseAmount = 1000000; break;
        case '80h': baseAmount = 1500000; break;
        case '100h': baseAmount = 2000000; break;
      }

      if (termId === 'cash') {
        totalAmount += baseAmount;
        details.push({
          concept: `Bolsa ${hoursType}`,
          paymentType: "Contado",
          amount: baseAmount,
          monthlyPayment: 0
        });
      } else {
        const term = terms?.find(t => t.id.toString() === termId);
        if (term) {
          let amount = baseAmount;
          if (term.months === 12) amount = baseAmount * 1.019;
          else if (term.months === 24) amount = baseAmount * 1.048;
          else if (term.months === 36) amount = baseAmount * 1.088;
          else if (term.months === 48) amount = baseAmount * 1.138;

          totalAmount += amount;
          monthlyPayment += amount / term.months;
          details.push({
            concept: `Bolsa ${hoursType}`,
            paymentType: `Financiado ${term.name}`,
            amount: amount,
            monthlyPayment: amount / term.months
          });
        }
      }
    }

    // Implementación
    if (selectedOptions.implementation === "cash") {
      const implCost = queryResults.implementationCost;
      totalAmount += implCost;
      details.push({
        concept: "Implementación",
        paymentType: "Contado",
        amount: implCost,
        monthlyPayment: 0
      });
    } else if (selectedOptions.implementation && selectedOptions.implementation.endsWith('-implementation')) {
        const termId = selectedOptions.implementation.split('-')[0];
        let implCost = queryResults.implementationCost;
        let rate = 1.0;

        switch(termId) {
          case '1': rate = 1.019; break;
          case '2': rate = 1.048; break;
          case '3': rate = 1.088; break;
          case '4': rate = 1.138; break;
        }

        const term = terms?.find(t => t.id.toString() === termId);
        if (term) {
          const finalAmount = implCost * rate;
          const implMonthlyPayment = finalAmount / term.months;
          totalAmount += finalAmount;
          monthlyPayment += implMonthlyPayment;
          details.push({
            concept: "Implementación",
            paymentType: `Financiado ${term.name}`,
            amount: finalAmount,
            monthlyPayment: implMonthlyPayment
          });
        }
    }


    return { totalAmount, monthlyPayment, details };
  };

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Calculadora de Licencias</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => window.history.back()}
          >
            Atrás
          </Button>

          <Link href="/">
            <Button variant="outline" className="flex items-center gap-2">
              Inicio
            </Button>
          </Link>
        </div>
      </div>

      <div className="space-y-4">
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Input
                placeholder="Cantidad de licencias"
                type="number"
                min="1"
                step="1"
                className="text-base"
                {...form.register("licenseQuantity")}
              />
              {form.formState.errors.licenseQuantity && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.licenseQuantity.message as string}
                </p>
              )}
            </div>

            <div>
              <Input
                placeholder="Precio unitario"
                type="number"
                min="0"
                step="0.01"
                className="text-base"
                {...form.register("licenseUnitPrice")}
              />
              {form.formState.errors.licenseUnitPrice && (
                <p className="text-red-500 text-sm mt-1">
                  {form.formState.errors.licenseUnitPrice.message as string}
                </p>
              )}
            </div>
          </div>

          <div className="flex gap-4 mt-4">
            <Button 
              type="submit"
              className="bg-black hover:bg-gray-800 text-white"
              disabled={createQueryMutation.isPending}
            >
              {createQueryMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Calcular
            </Button>

            <Button 
              type="button" 
              variant="outline"
              onClick={() => {
                form.reset();
                setQueryResults(null);
                setSelectedOptions({
                  licenses: "",
                  hourPackage: "",
                  implementation: ""
                });
              }}
            >
              Recalcular
            </Button>
          </div>
        </form>

        {queryResults && (
          <>
            <div className="rounded-md border mt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Concepto</TableHead>
                    <TableHead>Contado</TableHead>
                    <TableHead>12 meses</TableHead>
                    <TableHead>24 meses</TableHead>
                    <TableHead>36 meses</TableHead>
                    <TableHead>48 meses</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Licencias</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="licenses-payment" 
                          value="cash"
                          checked={selectedOptions.licenses === "cash"}
                          onChange={() => handlePaymentOptionChange("licenses", "cash")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(queryResults.totalLicenseCost)}
                      </div>
                    </TableCell>
                    {terms && terms.map((term: any) => {
                      const result = queryResults.financingOptions.find(
                        (opt: any) => opt.termId === term.id && opt.concept === "Licencias"
                      );
                      return (
                        <TableCell key={`license-${term.id}`}>
                          {result ? (
                            <div className="flex items-center gap-2">
                              <input 
                                type="checkbox" 
                                name="licenses-payment" 
                                value={term.id.toString()}
                                checked={selectedOptions.licenses === term.id.toString()}
                                onChange={() => handlePaymentOptionChange("licenses", term.id.toString())}
                                className="cursor-pointer"
                              />
                              {formatCurrency(result.totalAmount)}
                            </div>
                          ) : "N/A"}
                        </TableCell>
                      );
                    })}
                  </TableRow>

                  <TableRow>
                    <TableCell className="font-medium">Bolsa 30h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour30-payment" 
                          value="cash"
                          checked={selectedOptions.hourPackage === "cash-30h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "cash-30h" ? "" : "cash-30h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(500000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour30-payment"
                          value="1"
                          checked={selectedOptions.hourPackage === "1-30h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "1-30h" ? "" : "1-30h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(509900)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour30-payment"
                          value="2"
                          checked={selectedOptions.hourPackage === "2-30h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "2-30h" ? "" : "2-30h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(524300)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour30-payment"
                          value="3"
                          checked={selectedOptions.hourPackage === "3-30h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "3-30h" ? "" : "3-30h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(543900)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour30-payment"
                          value="4"
                          checked={selectedOptions.hourPackage === "4-30h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "4-30h" ? "" : "4-30h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(569100)}
                      </div>
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell className="font-medium">Bolsa 70h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour70-payment"
                          value="cash"
                          checked={selectedOptions.hourPackage === "cash-70h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "cash-70h" ? "" : "cash-70h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1000000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour70-payment"
                          value="1"
                          checked={selectedOptions.hourPackage === "1-70h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "1-70h" ? "" : "1-70h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1019000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour70-payment"
                          value="2"
                          checked={selectedOptions.hourPackage === "2-70h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "2-70h" ? "" : "2-70h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1048000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour70-payment"
                          value="3"
                          checked={selectedOptions.hourPackage === "3-70h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "3-70h" ? "" : "3-70h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1088000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour70-payment"
                          value="4"
                          checked={selectedOptions.hourPackage === "4-70h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "4-70h" ? "" : "4-70h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1138000)}
                      </div>
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell className="font-medium">Bolsa 80h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment" 
                          value="cash"
                          checked={selectedOptions.hourPackage === "cash-80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "cash-80h" ? "" : "cash-80h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1500000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment"
                          value="1"
                          checked={selectedOptions.hourPackage === "1-80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "1-80h" ? "" : "1-80h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1529000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment"
                          value="2"
                          checked={selectedOptions.hourPackage === "2-80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "2-80h" ? "" : "2-80h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1572000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment"
                          value="3"
                          checked={selectedOptions.hourPackage === "3-80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "3-80h" ? "" : "3-80h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1631000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment"
                          value="4"
                          checked={selectedOptions.hourPackage === "4-80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "4-80h" ? "" : "4-80h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1707000)}
                      </div>
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell className="font-medium">Bolsa 100h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour100-payment"
                          value="cash"
                          checked={selectedOptions.hourPackage === "cash-100h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "cash-100h" ? "" : "cash-100h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(2000000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour100-payment"
                          value="1"
                          checked={selectedOptions.hourPackage === "1-100h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "1-100h" ? "" : "1-100h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(2039000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour100-payment"
                          value="2"
                          checked={selectedOptions.hourPackage === "2-100h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "2-100h" ? "" : "2-100h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(2097000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour100-payment"
                          value="3"
                          checked={selectedOptions.hourPackage === "3-100h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "3-100h" ? "" : "3-100h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(2176000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour100-payment"
                          value="4"
                          checked={selectedOptions.hourPackage === "4-100h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "4-100h" ? "" : "4-100h")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(2276000)}
                      </div>
                    </TableCell>
                  </TableRow>

                  <TableRow>
                    <TableCell className="font-medium">Implementación</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="implementation-payment"
                          value="cash"
                          checked={selectedOptions.implementation === "cash"}
                          onChange={() => handlePaymentOptionChange("implementation", "cash")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(queryResults.implementationCost)}
                      </div>
                    </TableCell>
                    {terms && terms.map((term: any) => (
                      <TableCell key={`implementation-${term.id}`}>
                        <div className="flex items-center gap-2">
                          <input 
                            type="checkbox" 
                            name="implementation-payment"
                            value={`${term.id}-implementation`}
                            checked={selectedOptions.implementation === `${term.id}-implementation`}
                            onChange={() => handlePaymentOptionChange("implementation", `${term.id}-implementation`)}
                            className="cursor-pointer"
                          />
                          {formatCurrency(queryResults.implementationCost * (term.months === 12 ? 1.019 : term.months === 24 ? 1.048 : term.months === 36 ? 1.088 : term.months === 48 ? 1.138 : 1))}
                        </div>
                      </TableCell>
                    ))}
                  </TableRow>
                </TableBody>
              </Table>
            </div>

            {calculateSelectedTotal().details.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-2">Resumen de selección</h3>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Concepto</TableHead>
                        <TableHead>Modalidad</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Cuota mensual</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {calculateSelectedTotal().details.map((detail: any, index: number) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{detail.concept}</TableCell>
                          <TableCell>{detail.paymentType}</TableCell>
                          <TableCell>{formatCurrency(detail.amount)}</TableCell>
                          <TableCell>
                            {detail.monthlyPayment > 0 ? formatCurrency(detail.monthlyPayment) : "-"}
                          </TableCell>
                        </TableRow>
                      ))}

                      <TableRow className="bg-muted/50 font-semibold">
                        <TableCell colSpan={2}>TOTAL</TableCell>
                        <TableCell>{formatCurrency(calculateSelectedTotal().totalAmount)}</TableCell>
                        <TableCell>
                          {calculateSelectedTotal().monthlyPayment > 0 
                            ? formatCurrency(calculateSelectedTotal().monthlyPayment) 
                            : "-"}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                <div className="flex justify-center gap-4 mt-4">
                  <Button onClick={() => alert("Exportando PDF...")}>
                    Exportar PDF
                  </Button>

                  <Button 
                    variant="outline"
                    onClick={() => window.history.back()}
                  >
                    Volver
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}