
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";

export default function ReportsPage() {
  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ["/api/users"],
  });

  const { data: queries, isLoading: queriesLoading } = useQuery({
    queryKey: ["/api/queries"],
  });

  if (usersLoading || queriesLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const totalUsers = users?.length || 0;
  const totalQueries = queries?.length || 0;
  const avgQueriesPerUser = totalUsers ? (totalQueries / totalUsers).toFixed(2) : 0;

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Reportes del Sistema</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Total Usuarios</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalUsers}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total Consultas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{totalQueries}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Promedio Consultas/Usuario</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{avgQueriesPerUser}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
