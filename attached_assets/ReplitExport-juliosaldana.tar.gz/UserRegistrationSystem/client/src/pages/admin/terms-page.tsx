import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, ChevronLeft, Edit, Trash } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import TermForm from "@/components/admin/term-form";

export default function TermsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedTerm, setSelectedTerm] = useState<any>(null);
  
  // Obtener todos los plazos
  const { data: terms, isLoading, error } = useQuery({
    queryKey: ["/api/terms"],
    enabled: !!user && user.role === "admin"
  });
  
  // Mutación para eliminar plazo
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/terms/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/terms"]
      });
      toast({
        title: "Plazo eliminado",
        description: "El plazo ha sido eliminado exitosamente."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo eliminar el plazo: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Manejar eliminación de plazo
  const handleDelete = (id: number) => {
    if (window.confirm("¿Está seguro de que desea eliminar este plazo?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Abrir diálogo para editar
  const handleEdit = (term: any) => {
    setSelectedTerm(term);
    setDialogOpen(true);
  };
  
  // Abrir diálogo para crear
  const handleCreate = () => {
    setSelectedTerm(null);
    setDialogOpen(true);
  };
  
  // Cerrar diálogo
  const handleDialogClose = () => {
    setDialogOpen(false);
    setSelectedTerm(null);
  };
  
  if (!user || user.role !== "admin") {
    return <div className="text-center py-10">No tiene permisos para acceder a esta página.</div>;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Gestión de Plazos</h2>
        <div className="flex gap-2">
          <Link href="/admin">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <ChevronLeft className="h-4 w-4" />
              Volver
            </Button>
          </Link>
          
          <Button 
            onClick={handleCreate}
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Nuevo Plazo
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Plazos Disponibles</CardTitle>
          <CardDescription>Administre los plazos disponibles para las consultas financieras</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="py-4 text-center text-red-500">
              Error cargando plazos: {(error as Error).message}
            </div>
          ) : !terms || terms.length === 0 ? (
            <div className="py-6 text-center text-gray-500">
              <p>No hay plazos configurados.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={handleCreate}
              >
                <Plus className="mr-2 h-4 w-4" />
                Agregar Plazo
              </Button>
            </div>
          ) : (
            <div className="rounded-md border">
              <div className="grid grid-cols-5 gap-4 p-4 font-medium text-sm text-gray-500 bg-gray-50 border-b">
                <div className="col-span-2">Nombre</div>
                <div>Meses</div>
                <div>Descripción</div>
                <div className="text-right">Acciones</div>
              </div>
              <div className="divide-y">
                {terms.map((term: any) => (
                  <div key={term.id} className="grid grid-cols-5 gap-4 p-4 items-center">
                    <div className="col-span-2 font-medium">{term.name}</div>
                    <div>
                      <Badge variant="outline">{term.months} meses</Badge>
                    </div>
                    <div className="text-sm text-gray-600 truncate">
                      {term.description || "Sin descripción"}
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleEdit(term)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-red-500"
                        onClick={() => handleDelete(term.id)}
                        disabled={deleteMutation.isPending}
                      >
                        {deleteMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <TermForm 
            initialData={selectedTerm}
            onSuccess={handleDialogClose}
            onCancel={handleDialogClose}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}