import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Plus, ChevronLeft, Edit, Trash } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ConceptForm from "@/components/admin/concept-form";

export default function ConceptsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedConcept, setSelectedConcept] = useState<any>(null);
  
  // Obtener todos los conceptos
  const { data: concepts, isLoading, error } = useQuery({
    queryKey: ["/api/concepts"],
    enabled: !!user && user.role === "admin"
  });
  
  // Mutación para eliminar concepto
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/concepts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/concepts"]
      });
      toast({
        title: "Concepto eliminado",
        description: "El concepto ha sido eliminado exitosamente."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo eliminar el concepto: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Manejar eliminación de concepto
  const handleDelete = (id: number) => {
    if (window.confirm("¿Está seguro de que desea eliminar este concepto?")) {
      deleteMutation.mutate(id);
    }
  };
  
  // Abrir diálogo para editar
  const handleEdit = (concept: any) => {
    setSelectedConcept(concept);
    setDialogOpen(true);
  };
  
  // Abrir diálogo para crear
  const handleCreate = () => {
    setSelectedConcept(null);
    setDialogOpen(true);
  };
  
  // Cerrar diálogo
  const handleDialogClose = () => {
    setDialogOpen(false);
    setSelectedConcept(null);
  };
  
  // Categorías
  const getCategoryBadge = (category: string | null) => {
    if (!category) return "General";
    
    switch (category) {
      case "bolsa-horas":
        return "Bolsa de Horas";
      case "implementacion":
        return "Implementación";
      case "licencia":
        return "Licencia";
      default:
        return category;
    }
  };
  
  // Color del badge según categoría
  const getCategoryVariant = (category: string | null) => {
    if (!category) return "outline";
    
    switch (category) {
      case "bolsa-horas":
        return "secondary";
      case "implementacion":
        return "default";
      case "licencia":
        return "outline";
      default:
        return "outline";
    }
  };
  
  if (!user || user.role !== "admin") {
    return <div className="text-center py-10">No tiene permisos para acceder a esta página.</div>;
  }
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Gestión de Conceptos</h2>
        <div className="flex gap-2">
          <Link href="/admin">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <ChevronLeft className="h-4 w-4" />
              Volver
            </Button>
          </Link>
          
          <Button 
            onClick={handleCreate}
            className="flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Nuevo Concepto
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Conceptos</CardTitle>
          <CardDescription>Administre los conceptos disponibles para las consultas financieras</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="py-4 text-center text-red-500">
              Error cargando conceptos: {(error as Error).message}
            </div>
          ) : !concepts || concepts.length === 0 ? (
            <div className="py-6 text-center text-gray-500">
              <p>No hay conceptos configurados.</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={handleCreate}
              >
                <Plus className="mr-2 h-4 w-4" />
                Agregar Concepto
              </Button>
            </div>
          ) : (
            <div className="rounded-md border">
              <div className="grid grid-cols-5 gap-4 p-4 font-medium text-sm text-gray-500 bg-gray-50 border-b">
                <div className="col-span-2">Nombre</div>
                <div>Categoría</div>
                <div>Descripción</div>
                <div className="text-right">Acciones</div>
              </div>
              <div className="divide-y">
                {concepts.map((concept: any) => (
                  <div key={concept.id} className="grid grid-cols-5 gap-4 p-4 items-center">
                    <div className="col-span-2 font-medium">{concept.name}</div>
                    <div>
                      <Badge variant={getCategoryVariant(concept.category)}>
                        {getCategoryBadge(concept.category)}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 truncate">
                      {concept.description || "Sin descripción"}
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => handleEdit(concept)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="text-red-500"
                        onClick={() => handleDelete(concept.id)}
                        disabled={deleteMutation.isPending}
                      >
                        {deleteMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <ConceptForm 
            initialData={selectedConcept}
            onSuccess={handleDialogClose}
            onCancel={handleDialogClose}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}