import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { User as UserType } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Users, Package, Clock, FileText } from "lucide-react";
import { Link } from "wouter";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import UserForm from "@/components/admin/user-form";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";


export default function AdminDashboard() {
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const { data: users, isLoading, error } = useQuery<Omit<UserType, "password">[]>({
    queryKey: ["/api/users"],
    enabled: !!user && user.role === "admin",
  });

  const { data: concepts } = useQuery({
    queryKey: ["/api/concepts"],
    enabled: !!user && user.role === "admin",
  });

  const { data: terms } = useQuery({
    queryKey: ["/api/terms"],
    enabled: !!user && user.role === "admin",
  });

  // Stats calculation
  const totalUsers = users?.length || 0;
  const adminUsers = users?.filter(u => u.role === "admin").length || 0;
  const conceptsCount = concepts?.length || 0;
  const termsCount = terms?.length || 0;

  // Get users from the last 7 days
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

  const newUsers = users?.filter(u => {
    const lastLogin = u.lastLogin ? new Date(u.lastLogin) : null;
    return lastLogin && lastLogin > sevenDaysAgo;
  }).length || 0;

  // Editar usuario
  const handleEditUser = (userData: any) => {
    setSelectedUser(userData);
    setDialogOpen(true);
  };

  // Cerrar diálogo
  const handleDialogClose = () => {
    setDialogOpen(false);
    setSelectedUser(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Panel de Administración</h2>
        <div className="flex gap-2">
          <Link href="/">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              Inicio
            </Button>
          </Link>
        </div>
      </div>

      {/* Menu de Administración */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Link href="/admin" className="w-full">
          <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center justify-center space-y-2">
              <Users className="h-8 w-8 text-primary" />
              <div className="text-xl font-medium text-center">Usuarios</div>
              <div className="text-sm text-gray-500 text-center">
                Gestionar usuarios del sistema
              </div>
              <Badge className="mt-2">{totalUsers} usuarios</Badge>
            </CardContent>
          </Card>
        </Link>

        <Link href="/admin/concepts" className="w-full">
          <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center justify-center space-y-2">
              <Package className="h-8 w-8 text-primary" />
              <div className="text-xl font-medium text-center">Conceptos</div>
              <div className="text-sm text-gray-500 text-center">
                Configurar bolsas de horas e implementación
              </div>
              <Badge className="mt-2">{conceptsCount} conceptos</Badge>
            </CardContent>
          </Card>
        </Link>

        <Link href="/admin/terms" className="w-full">
          <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center justify-center space-y-2">
              <Clock className="h-8 w-8 text-primary" />
              <div className="text-xl font-medium text-center">Plazos</div>
              <div className="text-sm text-gray-500 text-center">
                Configurar plazos disponibles
              </div>
              <Badge className="mt-2">{termsCount} plazos</Badge>
            </CardContent>
          </Card>
        </Link>
        <Link href="/admin/reports" className="w-full">
          <Card className="hover:shadow-md transition-shadow cursor-pointer h-full">
            <CardContent className="p-6 flex flex-col items-center justify-center space-y-2">
              <FileText className="h-8 w-8 text-primary" />
              <div className="text-xl font-medium text-center">Reportes</div>
              <div className="text-sm text-gray-500 text-center">
                Ver estadísticas y reportes del sistema
              </div>
              <Badge className="mt-2">Ver reportes</Badge>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* System Overview Section */}
      <Card>
        <CardHeader>
          <CardTitle>Resumen del Sistema</CardTitle>
          <CardDescription>Métricas clave sobre los usuarios de la aplicación</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Card>
              <CardContent className="pt-6">
                <div className="text-sm font-medium text-gray-500">Total de Usuarios</div>
                <div className="mt-2 text-3xl font-semibold text-gray-900">{totalUsers}</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-sm font-medium text-gray-500">Usuarios Nuevos (7 días)</div>
                <div className="mt-2 text-3xl font-semibold text-gray-900">{newUsers}</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-sm font-medium text-gray-500">Administradores</div>
                <div className="mt-2 text-3xl font-semibold text-gray-900">{adminUsers}</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* User Management Section */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Gestión de Usuarios</CardTitle>
            <CardDescription>Administrar usuarios registrados</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : error ? (
            <div className="py-4 text-center text-red-500">
              Error cargando usuarios: {(error as Error).message}
            </div>
          ) : (
            <div className="rounded-md border">
              <div className="divide-y">
                {users && users.length > 0 ? (
                  users.map((u) => (
                    <div key={u.id} className="flex items-center justify-between p-4">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 bg-gray-200">
                          <AvatarFallback className="text-gray-600">
                            {u.firstName.charAt(0)}{u.lastName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {u.firstName} {u.lastName}
                          </div>
                          <div className="text-sm text-gray-500">{u.email}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge variant={u.role === "admin" ? "secondary" : "outline"}>
                          {u.role.charAt(0).toUpperCase() + u.role.slice(1)}
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleEditUser(u)}
                        >
                          Editar
                        </Button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-gray-500">No se encontraron usuarios</div>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Diálogo para editar usuario */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <div className="mb-4 text-xl font-semibold">Editar Usuario</div>
          {selectedUser && (
            <UserForm 
              initialData={selectedUser}
              onSuccess={handleDialogClose}
              onCancel={handleDialogClose}
            />
          )}
        </DialogContent>
      </Dialog>

      </div>
  );
}