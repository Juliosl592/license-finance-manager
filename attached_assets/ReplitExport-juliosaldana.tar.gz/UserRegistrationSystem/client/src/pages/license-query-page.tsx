import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Loader2, FileSpreadsheet, FileDown } from "lucide-react";
import { format } from "date-fns";

// Components
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

// Schema para validar el formulario de licencias
const licenseQuerySchema = z.object({
  licenseQuantity: z.string()
    .min(1, "La cantidad de licencias es requerida")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "Debe ser un número entero positivo"),
  licenseUnitPrice: z.string()
    .min(1, "El precio unitario es requerido")
    .transform(val => parseFloat(val))
    .refine(val => !isNaN(val) && val > 0, "Debe ser un número positivo"),
});

type LicenseQueryFormValues = z.infer<typeof licenseQuerySchema>;

export default function LicenseQueryPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("query");
  const [queryResults, setQueryResults] = useState<any>(null);
  const [selectedOptions, setSelectedOptions] = useState<{
    licenses: string;
    hourPackage: string;
    implementation: string;
  }>({
    licenses: "",
    hourPackage: "",
    implementation: ""
  });
  const [showSummary, setShowSummary] = useState(true);
  
  // Form
  const form = useForm<LicenseQueryFormValues>({
    resolver: zodResolver(licenseQuerySchema),
    defaultValues: {
      licenseQuantity: "",
      licenseUnitPrice: "",
    }
  });
  
  // Obtener conceptos (bolsas de horas)
  const { data: concepts, isLoading: loadingConcepts } = useQuery({
    queryKey: ["/api/concepts"],
    enabled: !!user
  });
  
  // Obtener plazos
  const { data: terms, isLoading: loadingTerms } = useQuery({
    queryKey: ["/api/terms"],
    enabled: !!user
  });
  
  // Obtener consultas recientes
  const { data: recentQueries, isLoading: loadingQueries } = useQuery({
    queryKey: ["/api/queries"],
    enabled: !!user
  });
  
  // Mutación para crear consulta
  const createQueryMutation = useMutation({
    mutationFn: async (data: any) => {
      try {
        console.log("Enviando datos al servidor:", data);
        const res = await apiRequest("POST", "/api/license-query", data);
        const jsonData = await res.json();
        console.log("Respuesta del servidor:", jsonData);
        return jsonData;
      } catch (error) {
        console.error("Error en la solicitud:", error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log("Datos procesados correctamente:", data);
      setQueryResults(data);
      setActiveTab("results"); // Cambiamos a la pestaña de resultados
      queryClient.invalidateQueries({
        queryKey: ["/api/queries"]
      });
      toast({
        title: "Consulta realizada",
        description: "Los resultados de su consulta están listos.",
      });
    },
    onError: (error: any) => {
      console.error("Error completo:", error);
      toast({
        title: "Error",
        description: "No se pudo realizar la consulta. Revise los datos e intente nuevamente.",
        variant: "destructive"
      });
    }
  });
  
  // Mutación para eliminar consulta
  const deleteQueryMutation = useMutation({
    mutationFn: async (queryId: number) => {
      await apiRequest("DELETE", `/api/queries/${queryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/queries"]
      });
      toast({
        title: "Consulta eliminada",
        description: "La consulta ha sido eliminada exitosamente.",
      });
    }
  });
  
  // Obtener bolsas de horas a partir de los conceptos
  const hourPackages = concepts?.filter((concept: any) => concept.category === "bolsa-horas") || [];
  
  // Manejar envío del formulario
  function onSubmit(values: LicenseQueryFormValues) {
    createQueryMutation.mutate({
      queryType: "license-calculation",
      parameters: values
    });
  }
  
  // Manejar eliminación de consulta
  const handleDeleteQuery = (id: number) => {
    if (window.confirm("¿Está seguro de que desea eliminar esta consulta?")) {
      deleteQueryMutation.mutate(id);
    }
  };
  
  // Formatear número a moneda
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('es-MX', {
      style: 'currency',
      currency: 'MXN'
    }).format(amount);
  };
  
  // Generar Excel (función simulada)
  const generateExcel = (query: any) => {
    console.log("Generando Excel para", query);
    alert("Exportación a Excel iniciada. El archivo se descargará pronto.");
  };
  
  // Generar PDF (función simulada)
  const generatePDF = (query: any) => {
    console.log("Generando PDF para", query);
    alert("Exportación a PDF iniciada. El archivo se descargará pronto.");
  };
  
  // Manejar selección de opciones de pago
  const handlePaymentOptionChange = (concept: string, termId: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [concept.toLowerCase().replace(" ", "")]: termId
    }));
  };
  
  // Calcular total según opciones seleccionadas
  const calculateSelectedTotal = () => {
    if (!queryResults) return { totalAmount: 0, monthlyPayment: 0, details: [] };
    
    let totalAmount = 0;
    let monthlyPayment = 0;
    const details: any[] = [];
    
    // Licencias
    if (selectedOptions.licenses === "cash") {
      totalAmount += queryResults.totalLicenseCost;
      details.push({
        concept: "Licencias",
        paymentType: "Contado",
        amount: queryResults.totalLicenseCost,
        monthlyPayment: 0
      });
    } else if (selectedOptions.licenses) {
      const termOption = queryResults.financingOptions.find(
        (opt: any) => opt.termId.toString() === selectedOptions.licenses && opt.concept === "Licencias"
      );
      if (termOption) {
        totalAmount += termOption.totalAmount;
        monthlyPayment += termOption.monthlyPayment;
        details.push({
          concept: "Licencias",
          paymentType: `Financiado ${termOption.term.name} (${termOption.term.months} meses)`,
          amount: termOption.totalAmount,
          monthlyPayment: termOption.monthlyPayment
        });
      }
    }
    
    // Implementación
    if (selectedOptions.implementation === "cash") {
      totalAmount += queryResults.implementationCost;
      details.push({
        concept: "Implementación",
        paymentType: "Contado",
        amount: queryResults.implementationCost,
        monthlyPayment: 0
      });
    } else if (selectedOptions.implementation) {
      const termOption = queryResults.financingOptions.find(
        (opt: any) => opt.termId.toString() === selectedOptions.implementation && opt.concept === "Implementación"
      );
      if (termOption) {
        totalAmount += termOption.totalAmount;
        monthlyPayment += termOption.monthlyPayment;
        details.push({
          concept: "Implementación",
          paymentType: `Financiado ${termOption.term.name} (${termOption.term.months} meses)`,
          amount: termOption.totalAmount,
          monthlyPayment: termOption.monthlyPayment
        });
      }
    }
    
    // Bolsa de Horas (si existe)
    if (queryResults.hourPackage) {
      if (selectedOptions.hourPackage === "cash") {
        totalAmount += queryResults.hourPackageCost;
        details.push({
          concept: "Bolsa de Horas",
          paymentType: "Contado",
          amount: queryResults.hourPackageCost,
          monthlyPayment: 0
        });
      } else if (selectedOptions.hourPackage) {
        const termOption = queryResults.financingOptions.find(
          (opt: any) => opt.termId.toString() === selectedOptions.hourPackage && opt.concept === "Bolsa de Horas"
        );
        if (termOption) {
          totalAmount += termOption.totalAmount;
          monthlyPayment += termOption.monthlyPayment;
          details.push({
            concept: "Bolsa de Horas",
            paymentType: `Financiado ${termOption.term.name} (${termOption.term.months} meses)`,
            amount: termOption.totalAmount,
            monthlyPayment: termOption.monthlyPayment
          });
        }
      }
    }
    
    return { totalAmount, monthlyPayment, details };
  };
  
  if (!user) return null;
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-gray-800">Calculadora de Licencias</h2>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="flex items-center gap-2"
            onClick={() => window.history.back()}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5M12 19l-7-7 7-7" />
            </svg>
            Atrás
          </Button>
          
          <Link href="/">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              Inicio
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <FormField
              control={form.control}
              name="licenseQuantity"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder="Cantidad de licencias"
                      type="number"
                      min="1"
                      step="1"
                      className="text-base"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div>
            <FormField
              control={form.control}
              name="licenseUnitPrice"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <Input
                      placeholder="Precio unitario"
                      type="number"
                      min="0"
                      step="0.01"
                      className="text-base"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <div className="flex gap-4">
          <Button 
            type="button" 
            onClick={form.handleSubmit(onSubmit)}
            className="bg-black hover:bg-gray-800 text-white"
            disabled={createQueryMutation.isPending}
          >
            {createQueryMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : null}
            Calcular
          </Button>
          
          <Button 
            type="button" 
            variant="outline"
            onClick={() => {
              form.reset();
              setQueryResults(null);
              setSelectedOptions({
                licenses: "",
                hourPackage: "",
                implementation: ""
              });
            }}
          >
            Recalcular
          </Button>
        </div>
        
          {queryResults && (
            <div className="rounded-md border mt-6">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Concepto</TableHead>
                    <TableHead>Contado</TableHead>
                    <TableHead>12 meses</TableHead>
                    <TableHead>24 meses</TableHead>
                    <TableHead>36 meses</TableHead>
                    <TableHead>48 meses</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Licencias</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="licenses-payment" 
                          value="cash"
                          checked={selectedOptions.licenses === "cash"}
                          onChange={() => handlePaymentOptionChange("licenses", "cash")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(queryResults.totalLicenseCost)}
                      </div>
                    </TableCell>
                    {terms && terms.map((term: any) => {
                      const result = queryResults.financingOptions.find(
                        (opt: any) => opt.termId === term.id && opt.concept === "Licencias"
                      );
                      return (
                        <TableCell key={`license-${term.id}`}>
                          {result ? (
                            <div className="flex items-center gap-2">
                              <input 
                                type="checkbox" 
                                name="licenses-payment" 
                                value={term.id.toString()}
                                checked={selectedOptions.licenses === term.id.toString()}
                                onChange={() => handlePaymentOptionChange("licenses", term.id.toString())}
                                className="cursor-pointer"
                              />
                              {formatCurrency(result.totalAmount)}
                            </div>
                          ) : "N/A"}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                          
                  <TableRow>
                    <TableCell className="font-medium">Bolsa 30h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(500000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(509900)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(524300)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(543900)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(569100)}
                      </div>
                    </TableCell>
                  </TableRow>
                          
                  <TableRow>
                    <TableCell className="font-medium">Bolsa 70h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1000000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1019000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1048000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1088000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1138000)}
                      </div>
                    </TableCell>
                  </TableRow>
                          
                  <TableRow>
                    <TableCell className="font-medium">Bolsa 80h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="hour80-payment" 
                          value="cash"
                          checked={selectedOptions.hourPackage === "cash" && queryResults.hourPackage?.name === "Bolsa 80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", "cash")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(1500000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          className="cursor-pointer"
                          checked={selectedOptions.hourPackage === "1" && queryResults.hourPackage?.name === "Bolsa 80h"}
                          onChange={() => handlePaymentOptionChange("hourPackage", "1")}
                        />
                        {formatCurrency(1529000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1572000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1631000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(1707000)}
                      </div>
                    </TableCell>
                  </TableRow>
                          
                  <TableRow>
                    <TableCell className="font-medium">Bolsa 100h</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(2000000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(2039000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(2097000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(2176000)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input type="checkbox" className="cursor-pointer" disabled />
                        {formatCurrency(2276000)}
                      </div>
                    </TableCell>
                  </TableRow>
                          
                  <TableRow>
                    <TableCell className="font-medium">Implementación</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <input 
                          type="checkbox" 
                          name="implementation-payment" 
                          value="cash"
                          checked={selectedOptions.implementation === "cash"}
                          onChange={() => handlePaymentOptionChange("implementation", "cash")}
                          className="cursor-pointer"
                        />
                        {formatCurrency(queryResults.implementationCost)}
                      </div>
                    </TableCell>
                    {terms && terms.map((term: any) => {
                      const result = queryResults.financingOptions.find(
                        (opt: any) => opt.termId === term.id && opt.concept === "Implementación"
                      );
                      return (
                        <TableCell key={`impl-${term.id}`}>
                          {result ? (
                            <div className="flex items-center gap-2">
                              <input 
                                type="checkbox" 
                                name="implementation-payment" 
                                value={term.id.toString()}
                                checked={selectedOptions.implementation === term.id.toString()}
                                onChange={() => handlePaymentOptionChange("implementation", term.id.toString())}
                                className="cursor-pointer"
                              />
                              {formatCurrency(result.totalAmount)}
                            </div>
                          ) : "N/A"}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                </TableBody>
              </Table>
            </div>
              
            {showSummary && (
              <div className="mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Resultados de la Consulta</CardTitle>
                    <CardDescription>Opciones de financiamiento según plazo</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!queryResults ? (
                      <Alert>
                  <AlertTitle>Sin resultados disponibles</AlertTitle>
                  <AlertDescription>
                    Realice una consulta en la pestaña "Nueva Consulta" para ver los resultados aquí.
                  </AlertDescription>
                </Alert>
              ) : loadingTerms ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm font-medium text-gray-500">Licencias</div>
                        <div className="mt-2 text-xl font-semibold text-gray-900">
                          {queryResults.licenseQuantity} unidades
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          @ {formatCurrency(queryResults.licenseUnitPrice)}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm font-medium text-gray-500">Total de Licencias</div>
                        <div className="mt-2 text-xl font-semibold text-gray-900">
                          {formatCurrency(queryResults.totalLicenseCost)}
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm font-medium text-gray-500">Implementación</div>
                        <div className="mt-2 text-xl font-semibold text-gray-900">
                          {formatCurrency(queryResults.implementationCost)}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  
                  {queryResults.hourPackage && (
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-sm font-medium text-gray-500">Bolsa de Horas</div>
                        <div className="mt-2 text-xl font-semibold text-gray-900">
                          {queryResults.hourPackage.name}
                        </div>
                        <div className="mt-1 text-sm text-gray-500">
                          {queryResults.hourPackage.description}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  {!showSummary ? (
                    <>
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Concepto</TableHead>
                              <TableHead>Costo de Contado</TableHead>
                              {terms && terms.map((term: any) => (
                                <TableHead key={term.id}>
                                  {term.name} ({term.months} meses)
                                </TableHead>
                              ))}
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            <TableRow>
                              <TableCell className="font-medium">Licencias</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox" 
                                    name="licenses-payment" 
                                    value="cash"
                                    checked={selectedOptions.licenses === "cash"}
                                    onChange={() => handlePaymentOptionChange("licenses", selectedOptions.licenses === "cash" ? "" : "cash")}
                                    className="cursor-pointer"
                                  />
                                  {formatCurrency(queryResults.totalLicenseCost)}
                                </div>
                              </TableCell>
                              {terms && terms.map((term: any) => {
                                const result = queryResults.financingOptions.find(
                                  (opt: any) => opt.termId === term.id && opt.concept === "Licencias"
                                );
                                return (
                                  <TableCell key={`license-${term.id}`}>
                                    {result ? (
                                      <div className="flex items-center gap-2">
                                        <input 
                                          type="checkbox" 
                                          name="licenses-payment" 
                                          value={term.id.toString()}
                                          checked={selectedOptions.licenses === term.id.toString()}
                                          onChange={() => handlePaymentOptionChange("licenses", selectedOptions.licenses === term.id.toString() ? "" : term.id.toString())}
                                          className="cursor-pointer"
                                        />
                                        <div>
                                          {formatCurrency(result.totalAmount)}
                                          <div className="text-xs text-gray-500">
                                            ({formatCurrency(result.monthlyPayment)}/mes)
                                          </div>
                                        </div>
                                      </div>
                                    ) : "N/A"}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                            
                            <TableRow>
                              <TableCell className="font-medium">Implementación</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <input 
                                    type="checkbox" 
                                    name="implementation-payment" 
                                    value="cash"
                                    checked={selectedOptions.implementation === "cash"}
                                    onChange={() => handlePaymentOptionChange("implementation", selectedOptions.implementation === "cash" ? "" : "cash")}
                                    className="cursor-pointer"
                                  />
                                  {formatCurrency(queryResults.implementationCost)}
                                </div>
                              </TableCell>
                              {terms && terms.map((term: any) => {
                                const result = queryResults.financingOptions.find(
                                  (opt: any) => opt.termId === term.id && opt.concept === "Implementación"
                                );
                                return (
                                  <TableCell key={`impl-${term.id}`}>
                                    {result ? (
                                      <div className="flex items-center gap-2">
                                        <input 
                                          type="checkbox" 
                                          name="implementation-payment" 
                                          value={term.id.toString()}
                                          checked={selectedOptions.implementation === term.id.toString()}
                                          onChange={() => handlePaymentOptionChange("implementation", selectedOptions.implementation === term.id.toString() ? "" : term.id.toString())}
                                          className="cursor-pointer"
                                        />
                                        <div>
                                          {formatCurrency(result.totalAmount)}
                                          <div className="text-xs text-gray-500">
                                            ({formatCurrency(result.monthlyPayment)}/mes)
                                          </div>
                                        </div>
                                      </div>
                                    ) : "N/A"}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                            
                            {queryResults.hourPackage && (
                              <TableRow>
                                <TableCell className="font-medium">Bolsa de Horas</TableCell>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    <input 
                                      type="checkbox" 
                                      name="hourPackage-payment" 
                                      value="cash"
                                      checked={selectedOptions.hourPackage === "cash"}
                                      onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === "cash" ? "" : "cash")}
                                      className="cursor-pointer"
                                    />
                                    {formatCurrency(queryResults.hourPackageCost)}
                                  </div>
                                </TableCell>
                                {terms && terms.map((term: any) => {
                                  const result = queryResults.financingOptions.find(
                                    (opt: any) => opt.termId === term.id && opt.concept === "Bolsa de Horas"
                                  );
                                  return (
                                    <TableCell key={`hours-${term.id}`}>
                                      {result ? (
                                        <div className="flex items-center gap-2">
                                          <input 
                                            type="checkbox" 
                                            name="hourPackage-payment" 
                                            value={term.id.toString()}
                                            checked={selectedOptions.hourPackage === term.id.toString()}
                                            onChange={() => handlePaymentOptionChange("hourPackage", selectedOptions.hourPackage === term.id.toString() ? "" : term.id.toString())}
                                            className="cursor-pointer"
                                          />
                                          <div>
                                            {formatCurrency(result.totalAmount)}
                                            <div className="text-xs text-gray-500">
                                              ({formatCurrency(result.monthlyPayment)}/mes)
                                            </div>
                                          </div>
                                        </div>
                                      ) : "N/A"}
                                    </TableCell>
                                  );
                                })}
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                      
                      <div className="flex justify-center mt-6">
                        <Button 
                          onClick={() => setShowSummary(true)}
                          className="px-6"
                        >
                          Ver resumen de selección
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="space-y-6">
                      <Card>
                        <CardHeader>
                          <CardTitle>Resumen de opciones seleccionadas</CardTitle>
                          <CardDescription>Detalle de los conceptos y modalidades de pago seleccionadas</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="rounded-md border">
                            <Table>
                              <TableHeader>
                                <TableRow>
                                  <TableHead>Concepto</TableHead>
                                  <TableHead>Modalidad de pago</TableHead>
                                  <TableHead>Valor</TableHead>
                                  <TableHead>Cuota mensual</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {calculateSelectedTotal().details.map((detail: any, index: number) => (
                                  <TableRow key={index}>
                                    <TableCell className="font-medium">{detail.concept}</TableCell>
                                    <TableCell>{detail.paymentType}</TableCell>
                                    <TableCell>{formatCurrency(detail.amount)}</TableCell>
                                    <TableCell>{detail.monthlyPayment > 0 ? formatCurrency(detail.monthlyPayment) : "N/A"}</TableCell>
                                  </TableRow>
                                ))}
                                <TableRow className="bg-muted/50 font-semibold">
                                  <TableCell colSpan={2}>TOTAL</TableCell>
                                  <TableCell>{formatCurrency(calculateSelectedTotal().totalAmount)}</TableCell>
                                  <TableCell>{calculateSelectedTotal().monthlyPayment > 0 ? formatCurrency(calculateSelectedTotal().monthlyPayment) : "N/A"}</TableCell>
                                </TableRow>
                              </TableBody>
                            </Table>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <div className="flex justify-center gap-4">
                        <Button 
                          onClick={() => setShowSummary(false)}
                          variant="outline"
                        >
                          Volver a opciones
                        </Button>
                        
                        <Button onClick={() => generatePDF(calculateSelectedTotal())}>
                          Exportar a PDF
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
              </Card>
            </div>
            )}
            
            <CardFooter className="flex justify-end space-x-2">
              <Button 
                variant="outline" 
                disabled={!queryResults}
                onClick={() => queryResults && generateExcel(queryResults)}
              >
                <FileSpreadsheet className="mr-2 h-4 w-4" />
                Exportar a Excel
              </Button>
              <Button
                disabled={!queryResults}
                onClick={() => queryResults && generatePDF(queryResults)}
              >
                <FileDown className="mr-2 h-4 w-4" />
                Generar PDF
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}