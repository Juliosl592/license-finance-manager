import { useState } from "react";
import { cn } from "@/lib/utils";
import LoginForm from "./login-form";
import RegisterForm from "./register-form";

export default function AuthTabs() {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  
  return (
    <div className="max-w-md w-full mx-auto mt-8 mb-6 bg-white rounded-lg shadow-sm">
      <div className="flex">
        <button
          onClick={() => setActiveTab("login")}
          className={cn(
            "w-1/2 py-4 text-center font-medium rounded-tl-lg border-b",
            activeTab === "login"
              ? "bg-white text-gray-800 border-b-2 border-primary"
              : "bg-gray-100 text-gray-500 border-gray-200"
          )}
        >
          Login
        </button>
        <button
          onClick={() => setActiveTab("register")}
          className={cn(
            "w-1/2 py-4 text-center font-medium rounded-tr-lg border-b",
            activeTab === "register"
              ? "bg-white text-gray-800 border-b-2 border-primary"
              : "bg-gray-100 text-gray-500 border-gray-200"
          )}
        >
          Register
        </button>
      </div>
      
      <div className={cn("p-6", activeTab === "login" ? "block" : "hidden")}>
        <LoginForm />
      </div>
      
      <div className={cn("p-6", activeTab === "register" ? "block" : "hidden")}>
        <RegisterForm />
      </div>
    </div>
  );
}
