import { User, SquareStack } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Navbar() {
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const isAdmin = user?.role === "admin";
  
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/" className="text-primary font-bold text-xl cursor-pointer">
                Project Bolt
              </Link>
            </div>
          </div>
          
          {user ? (
            <div className="flex items-center">
              {isAdmin && (
                <Link href="/admin" className="px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50">
                  Dashboard
                </Link>
              )}
              
              <Link 
                href={isAdmin ? "/admin" : "/profile"} 
                className="px-3 py-2 rounded-md text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50"
              >
                {isAdmin ? "Users" : "Profile"}
              </Link>
              
              {!isAdmin && (
                <>
                  <Link 
                    href="/license-query" 
                    className="px-3 py-2 rounded-md text-sm font-medium text-blue-600 hover:text-blue-900 hover:bg-blue-50 flex items-center gap-1"
                  >
                    <SquareStack className="w-4 h-4" />
                    Licencias
                  </Link>

                </>
              )}
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      {user.firstName.charAt(0).toUpperCase()}
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer" asChild>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  {!isAdmin && (
                    <>
                      <DropdownMenuItem className="cursor-pointer" asChild>
                        <Link href="/license-query" className="flex items-center gap-2">
                          <SquareStack className="w-4 h-4 text-blue-600" />
                          Consulta de Licencias
                        </Link>
                      </DropdownMenuItem>

                    </>
                  )}
                  <DropdownMenuItem className="cursor-pointer">Settings</DropdownMenuItem>
                  <DropdownMenuItem 
                    className="cursor-pointer text-red-600 hover:text-red-800"
                    onClick={handleLogout}
                    disabled={logoutMutation.isPending}
                  >
                    {logoutMutation.isPending ? "Logging out..." : "Logout"}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <div className="flex items-center">
              <Link href="/auth">
                <Button variant="ghost" className="cursor-pointer">Login</Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
