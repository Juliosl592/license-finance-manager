import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

// Schema para validar el formulario
const rateFormSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  rate: z.string().min(1, "La tasa es requerida")
    .refine(val => !isNaN(parseFloat(val)), "La tasa debe ser un número"),
  description: z.string().nullable().optional(),
});

type RateFormValues = z.infer<typeof rateFormSchema>;

interface InterestRateFormProps {
  initialData?: {
    id: number;
    name: string;
    rate: string;
    description: string | null;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

export default function InterestRateForm({ initialData, onSuccess, onCancel }: InterestRateFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!initialData;

  // Inicializar el formulario
  const form = useForm<RateFormValues>({
    resolver: zodResolver(rateFormSchema),
    defaultValues: {
      name: initialData?.name || "",
      rate: initialData?.rate || "",
      description: initialData?.description || "",
    },
  });

  // Mutación para crear/actualizar tasa
  const mutation = useMutation({
    mutationFn: async (values: RateFormValues) => {
      if (isEditing && initialData) {
        const res = await apiRequest("PATCH", `/api/interest-rates/${initialData.id}`, values);
        return await res.json();
      } else {
        const res = await apiRequest("POST", "/api/interest-rates", values);
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/interest-rates"],
      });
      toast({
        title: isEditing ? "Tasa actualizada" : "Tasa creada",
        description: isEditing
          ? "La tasa de interés ha sido actualizada exitosamente."
          : "La tasa de interés ha sido creada exitosamente.",
      });
      onSuccess();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo ${isEditing ? "actualizar" : "crear"} la tasa: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Manejar envío del formulario
  function onSubmit(data: RateFormValues) {
    mutation.mutate(data);
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">
        {isEditing ? "Editar Tasa de Interés" : "Nueva Tasa de Interés"}
      </h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nombre</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. Tasa Ordinaria" {...field} />
                </FormControl>
                <FormDescription>
                  Un nombre descriptivo para esta tasa de interés.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="rate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tasa (%)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01" 
                    min="0"
                    placeholder="Ej. 12.5" 
                    {...field} 
                  />
                </FormControl>
                <FormDescription>
                  El porcentaje de interés (Ej. 12.5 para 12.5%).
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Descripción</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Descripción opcional para esta tasa" 
                    className="resize-none"
                    {...field}
                    value={field.value || ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end space-x-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              disabled={mutation.isPending}
            >
              {mutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isEditing ? "Actualizar" : "Crear"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}