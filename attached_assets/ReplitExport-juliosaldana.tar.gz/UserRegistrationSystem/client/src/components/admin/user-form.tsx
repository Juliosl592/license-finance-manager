import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

// Schema para validar el formulario
const userFormSchema = z.object({
  firstName: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  lastName: z.string().min(2, "El apellido debe tener al menos 2 caracteres"),
  email: z.string().email("Ingrese un correo electrónico válido"),
  role: z.string(),
  resetPassword: z.boolean().optional(),
  newPassword: z.string().optional().refine(val => {
    // Si resetPassword es true, la contraseña debe tener al menos 6 caracteres
    // Si no, puede estar vacía
    return val === undefined || val === "" || val.length >= 6;
  }, "La contraseña debe tener al menos 6 caracteres"),
});

type UserFormValues = z.infer<typeof userFormSchema>;

interface UserFormProps {
  initialData: {
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

export default function UserForm({ initialData, onSuccess, onCancel }: UserFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Inicializar el formulario
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: {
      firstName: initialData.firstName,
      lastName: initialData.lastName,
      email: initialData.email,
      role: initialData.role,
      resetPassword: false,
      newPassword: "",
    },
  });

  // Verificar si se ha marcado resetear contraseña
  const resetPassword = form.watch("resetPassword");

  // Mutación para actualizar usuario
  const mutation = useMutation({
    mutationFn: async (values: UserFormValues) => {
      const userData = {
        firstName: values.firstName,
        lastName: values.lastName,
        email: values.email,
        role: values.role,
      };

      // Si se ha marcado resetear contraseña, incluir la nueva contraseña
      if (values.resetPassword && values.newPassword) {
        Object.assign(userData, { password: values.newPassword });
      }

      const res = await apiRequest("PATCH", `/api/users/${initialData.id}`, userData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
      toast({
        title: "Usuario actualizado",
        description: "El usuario ha sido actualizado exitosamente.",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo actualizar el usuario: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutación para eliminar usuario
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/users/${initialData.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/users"],
      });
      toast({
        title: "Usuario eliminado",
        description: "El usuario ha sido eliminado exitosamente.",
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo eliminar el usuario: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Manejar envío del formulario
  function onSubmit(data: UserFormValues) {
    mutation.mutate(data);
  }

  // Manejar eliminación de usuario
  function handleDelete() {
    if (window.confirm(`¿Está seguro de que desea eliminar al usuario ${initialData.firstName} ${initialData.lastName}?`)) {
      deleteMutation.mutate();
    }
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">
        Editar Usuario: {initialData.firstName} {initialData.lastName}
      </h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Apellido</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Correo Electrónico</FormLabel>
                <FormControl>
                  <Input type="email" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Rol</FormLabel>
                <FormControl>
                  <Select
                    value={field.value}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione un rol" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">Usuario</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                    </SelectContent>
                  </Select>
                </FormControl>
                <FormDescription>
                  Determina los permisos del usuario en el sistema.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="resetPassword"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Resetear Contraseña</FormLabel>
                  <FormDescription>
                    Marque esta opción para establecer una nueva contraseña para este usuario.
                  </FormDescription>
                </div>
              </FormItem>
            )}
          />
          
          {resetPassword && (
            <FormField
              control={form.control}
              name="newPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nueva Contraseña</FormLabel>
                  <FormControl>
                    <Input 
                      type="password"
                      placeholder="Ingrese la nueva contraseña" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Debe tener al menos 6 caracteres.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <div className="flex justify-between">
            <Button 
              type="button" 
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Eliminar Usuario
            </Button>
            
            <div className="flex space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onCancel}
              >
                Cancelar
              </Button>
              <Button 
                type="submit"
                disabled={mutation.isPending}
              >
                {mutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Guardar Cambios
              </Button>
            </div>
          </div>
        </form>
      </Form>
    </div>
  );
}