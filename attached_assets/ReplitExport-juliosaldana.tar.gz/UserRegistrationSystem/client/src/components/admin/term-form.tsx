import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

// Schema para validar el formulario
const termFormSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  months: z.string().min(1, "El plazo en meses es requerido")
    .transform(val => parseInt(val))
    .refine(val => !isNaN(val) && val > 0, "El plazo debe ser un número entero positivo"),
  description: z.string().nullable().optional(),
});

type TermFormValues = z.infer<typeof termFormSchema>;

interface TermFormProps {
  initialData?: {
    id: number;
    name: string;
    months: number;
    description: string | null;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

export default function TermForm({ initialData, onSuccess, onCancel }: TermFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!initialData;

  // Inicializar el formulario
  const form = useForm<TermFormValues>({
    resolver: zodResolver(termFormSchema),
    defaultValues: {
      name: initialData?.name || "",
      months: initialData?.months ? initialData.months.toString() : "",
      description: initialData?.description || "",
    },
  });

  // Mutación para crear/actualizar plazo
  const mutation = useMutation({
    mutationFn: async (values: TermFormValues) => {
      if (isEditing && initialData) {
        const res = await apiRequest("PATCH", `/api/terms/${initialData.id}`, values);
        return await res.json();
      } else {
        const res = await apiRequest("POST", "/api/terms", values);
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/terms"],
      });
      toast({
        title: isEditing ? "Plazo actualizado" : "Plazo creado",
        description: isEditing
          ? "El plazo ha sido actualizado exitosamente."
          : "El plazo ha sido creado exitosamente.",
      });
      onSuccess();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo ${isEditing ? "actualizar" : "crear"} el plazo: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Manejar envío del formulario
  function onSubmit(data: TermFormValues) {
    mutation.mutate(data);
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">
        {isEditing ? "Editar Plazo" : "Nuevo Plazo"}
      </h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nombre</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. Corto Plazo" {...field} />
                </FormControl>
                <FormDescription>
                  Un nombre descriptivo para este plazo.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="months"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Plazo (meses)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    step="1"
                    placeholder="Ej. 12" 
                    {...field} 
                  />
                </FormControl>
                <FormDescription>
                  La duración en meses de este plazo.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Descripción</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Descripción opcional para este plazo" 
                    className="resize-none"
                    {...field}
                    value={field.value || ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end space-x-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              disabled={mutation.isPending}
            >
              {mutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isEditing ? "Actualizar" : "Crear"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}