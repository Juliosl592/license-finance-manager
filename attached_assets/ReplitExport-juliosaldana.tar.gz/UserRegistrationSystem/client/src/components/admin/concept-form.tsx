import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Schema para validar el formulario
const conceptFormSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  description: z.string().nullable().optional(),
  category: z.string().nullable().optional(),
  value: z.string()
    .optional()
    .transform(value => {
      if (value === "" || value === undefined) return undefined;
      // Convertir a número para la base de datos
      return parseFloat(value);
    }),
  hours: z.string().optional().transform(value => value === "" ? undefined : value),
});

type ConceptFormValues = z.infer<typeof conceptFormSchema>;

interface ConceptFormProps {
  initialData?: {
    id: number;
    name: string;
    description: string | null;
    category: string | null;
    value: number | null;
  };
  onSuccess: () => void;
  onCancel: () => void;
}

export default function ConceptForm({ initialData, onSuccess, onCancel }: ConceptFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!initialData;

  // Categorías predefinidas
  const categories = [
    { value: "bolsa-horas", label: "Bolsa de Horas" },
    { value: "implementacion", label: "Implementación" },
    { value: "licencia", label: "Licencia" }
  ];

  // Inicializar el formulario
  const form = useForm<ConceptFormValues>({
    resolver: zodResolver(conceptFormSchema),
    defaultValues: {
      name: initialData?.name || "",
      description: initialData?.description || "",
      category: initialData?.category || "bolsa-horas",
      value: initialData?.value ? String(initialData.value) : "",
      hours: "",
    },
  });

  // Obtener la categoría seleccionada
  const category = form.watch("category");
  const isBolsaHoras = category === "bolsa-horas";
  const isImplementacion = category === "implementacion";
  const showValueField = isBolsaHoras || isImplementacion;

  // Mutación para crear/actualizar concepto
  const mutation = useMutation({
    mutationFn: async (values: ConceptFormValues) => {
      // Si es bolsa de horas, añadir información en la descripción
      if (isBolsaHoras && values.hours && values.value) {
        values.description = `${values.hours} horas: $${values.value}`;
      }
      
      // Si es implementación, añadir información en la descripción
      if (isImplementacion && values.value) {
        values.description = `Implementación de licencias: $${values.value}`;
      }

      if (isEditing && initialData) {
        const res = await apiRequest("PATCH", `/api/concepts/${initialData.id}`, values);
        return await res.json();
      } else {
        const res = await apiRequest("POST", "/api/concepts", values);
        return await res.json();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["/api/concepts"],
      });
      toast({
        title: isEditing ? "Concepto actualizado" : "Concepto creado",
        description: isEditing
          ? "El concepto ha sido actualizado exitosamente."
          : "El concepto ha sido creado exitosamente.",
      });
      onSuccess();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: `No se pudo ${isEditing ? "actualizar" : "crear"} el concepto: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Manejar envío del formulario
  function onSubmit(data: ConceptFormValues) {
    mutation.mutate(data);
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">
        {isEditing ? "Editar Concepto" : "Nuevo Concepto"}
      </h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nombre</FormLabel>
                <FormControl>
                  <Input placeholder="Ej. Bolsa 30 horas" {...field} />
                </FormControl>
                <FormDescription>
                  Un nombre descriptivo para este concepto.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="category"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Categoría</FormLabel>
                <FormControl>
                  <Select
                    value={field.value || "bolsa-horas"}
                    onValueChange={field.onChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccione una categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem 
                          key={category.value} 
                          value={category.value}
                        >
                          {category.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          {/* Campo de horas solo para bolsas de horas */}
          {isBolsaHoras && (
            <FormField
              control={form.control}
              name="hours"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Cantidad de Horas</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="1" 
                      step="1"
                      placeholder="Ej. 30" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          {/* Campo de valor para bolsas de horas e implementación */}
          {showValueField && (
            <FormField
              control={form.control}
              name="value"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Precio ($)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="0" 
                      step="1"
                      placeholder={isImplementacion ? "Ej. 2800000" : "Ej. 500000"} 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    {isImplementacion ? "Valor de la implementación de licencias" : "Valor de la bolsa de horas"}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Descripción</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Descripción opcional para este concepto" 
                    className="resize-none"
                    {...field}
                    value={field.value || ""}
                    disabled={isBolsaHoras || isImplementacion}
                  />
                </FormControl>
                {(isBolsaHoras || isImplementacion) && (
                  <FormDescription>
                    {isImplementacion 
                      ? "La descripción se generará automáticamente con el valor de implementación." 
                      : "La descripción se generará automáticamente en base a las horas y precio."}
                  </FormDescription>
                )}
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end space-x-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onCancel}
            >
              Cancelar
            </Button>
            <Button 
              type="submit"
              disabled={mutation.isPending}
            >
              {mutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {isEditing ? "Actualizar" : "Crear"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}