import { pgTable, text, serial, timestamp, boolean, numeric, integer, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("user"),
  lastLogin: timestamp("last_login"),
  isActive: boolean("is_active").default(true),
});

export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, lastLogin: true, isActive: true })
  .extend({
    confirmPassword: z.string(),
  });

export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

// Tabla para tasas de interés
export const interestRates = pgTable("interest_rates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rate: numeric("rate").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

// Tabla para plazos
export const terms = pgTable("terms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  months: integer("months").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

// Tabla para conceptos
export const concepts = pgTable("concepts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  value: numeric("value", { precision: 10, scale: 2 }), // Valor monetario del concepto
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: integer("created_by").references(() => users.id),
});

// Consultas/Simulaciones realizadas por los usuarios
export const queries = pgTable("queries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  queryType: text("query_type").notNull(),
  parameters: jsonb("parameters").notNull(),
  results: jsonb("results"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
});

// Schemas para inserción
export const insertInterestRateSchema = createInsertSchema(interestRates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTermSchema = createInsertSchema(terms).omit({ id: true, createdAt: true, updatedAt: true });
export const insertConceptSchema = createInsertSchema(concepts).omit({ id: true, createdAt: true, updatedAt: true });
export const insertQuerySchema = createInsertSchema(queries).omit({ id: true, createdAt: true, expiresAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;
export type InterestRate = typeof interestRates.$inferSelect;
export type Term = typeof terms.$inferSelect;
export type Concept = typeof concepts.$inferSelect;
export type Query = typeof queries.$inferSelect;
export type InsertInterestRate = z.infer<typeof insertInterestRateSchema>;
export type InsertTerm = z.infer<typeof insertTermSchema>;
export type InsertConcept = z.infer<typeof insertConceptSchema>;
export type InsertQuery = z.infer<typeof insertQuerySchema>;
