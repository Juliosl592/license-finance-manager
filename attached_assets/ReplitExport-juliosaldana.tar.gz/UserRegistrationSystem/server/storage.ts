import { 
  users, interestRates, terms, concepts, queries,
  type User, type InsertUser, 
  type InterestRate, type InsertInterestRate,
  type Term, type InsertTerm,
  type Concept, type InsertConcept,
  type Query, type InsertQuery
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const MemoryStore = createMemoryStore(session);
const scryptAsync = promisify(scrypt);

// Utility function for password hashing
async function createHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

export interface IStorage {
  // Gestión de usuarios
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastLogin(id: number): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: number, userData: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  
  // Tasas de interés
  createInterestRate(data: InsertInterestRate): Promise<InterestRate>;
  getInterestRate(id: number): Promise<InterestRate | undefined>;
  getAllInterestRates(): Promise<InterestRate[]>;
  updateInterestRate(id: number, data: Partial<InterestRate>): Promise<InterestRate | undefined>;
  deleteInterestRate(id: number): Promise<boolean>;
  
  // Plazos
  createTerm(data: InsertTerm): Promise<Term>;
  getTerm(id: number): Promise<Term | undefined>;
  getAllTerms(): Promise<Term[]>;
  updateTerm(id: number, data: Partial<Term>): Promise<Term | undefined>;
  deleteTerm(id: number): Promise<boolean>;
  
  // Conceptos
  createConcept(data: InsertConcept): Promise<Concept>;
  getConcept(id: number): Promise<Concept | undefined>;
  getAllConcepts(): Promise<Concept[]>;
  updateConcept(id: number, data: Partial<Concept>): Promise<Concept | undefined>;
  deleteConcept(id: number): Promise<boolean>;
  
  // Consultas
  createQuery(data: InsertQuery): Promise<Query>;
  getQuery(id: number): Promise<Query | undefined>;
  getQueriesByUser(userId: number, limit?: number): Promise<Query[]>;
  getAllQueries(): Promise<Query[]>;
  deleteQuery(id: number): Promise<boolean>;
  deleteExpiredQueries(): Promise<number>; // Retorna el número de consultas eliminadas
  
  // Sesión
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private interestRates: Map<number, InterestRate>;
  private terms: Map<number, Term>;
  private concepts: Map<number, Concept>;
  private queries: Map<number, Query>;
  private userCurrentId: number;
  private interestRateCurrentId: number;
  private termCurrentId: number;
  private conceptCurrentId: number;
  private queryCurrentId: number;
  sessionStore: session.Store;

  constructor() {
    // Inicializar colecciones
    this.users = new Map();
    this.interestRates = new Map();
    this.terms = new Map();
    this.concepts = new Map();
    this.queries = new Map();
    
    // Inicializar contadores de IDs
    this.userCurrentId = 1;
    this.interestRateCurrentId = 1;
    this.termCurrentId = 1;
    this.conceptCurrentId = 1;
    this.queryCurrentId = 1;
    
    // Set up the session store
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Create a simple admin user with a plain text password that will be hashed during login
    this.setUpAdminUser();
    
    // Inicializar datos de prueba después de crear el admin
    setTimeout(() => this.setUpSampleData(), 100);
  }
  
  private async setUpAdminUser() {
    try {
      // Simple admin password for testing
      const adminData: Omit<InsertUser, "confirmPassword"> = {
        username: "admin",
        firstName: "Admin",
        lastName: "User",
        email: "admin@example.com",
        password: "admin123", // This will get hashed in createUser
        role: "admin"
      };
      
      // Create admin user using the same method we use for regular users
      await this.createUser(adminData);
      
      console.log("Admin user created successfully with username 'admin' and password 'admin123'");
    } catch (error) {
      console.error("Error creating admin user:", error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: Omit<InsertUser, "confirmPassword">): Promise<User> {
    const id = this.userCurrentId++;
    const now = new Date();
    
    // Hash the password if it's not already hashed (doesn't contain a dot)
    let password = insertUser.password;
    if (!password.includes('.')) {
      password = await createHash(password);
    }
    
    const user: User = { 
      ...insertUser,
      password, 
      id,
      lastLogin: now,
      isActive: true,
      role: insertUser.role || "user" // Ensure role is always defined
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = {
      ...user,
      lastLogin: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    // No permitir cambios del rol o contraseña a través de esta función
    const { role, password, id: userId, ...allowedUpdates } = userData;
    
    const updatedUser = {
      ...user,
      ...allowedUpdates
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // No permitir eliminar al usuario administrador
    const user = this.users.get(id);
    if (!user || user.role === 'admin') return false;
    
    return this.users.delete(id);
  }
  
  // Métodos para tasas de interés
  async createInterestRate(data: InsertInterestRate): Promise<InterestRate> {
    const id = this.interestRateCurrentId++;
    const now = new Date();
    
    const interestRate: InterestRate = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    
    this.interestRates.set(id, interestRate);
    return interestRate;
  }
  
  async getInterestRate(id: number): Promise<InterestRate | undefined> {
    return this.interestRates.get(id);
  }
  
  async getAllInterestRates(): Promise<InterestRate[]> {
    return Array.from(this.interestRates.values());
  }
  
  async updateInterestRate(id: number, data: Partial<InterestRate>): Promise<InterestRate | undefined> {
    const interestRate = this.interestRates.get(id);
    if (!interestRate) return undefined;
    
    const { id: rateId, createdAt, ...allowedUpdates } = data;
    
    const updatedInterestRate = {
      ...interestRate,
      ...allowedUpdates,
      updatedAt: new Date()
    };
    
    this.interestRates.set(id, updatedInterestRate);
    return updatedInterestRate;
  }
  
  async deleteInterestRate(id: number): Promise<boolean> {
    return this.interestRates.delete(id);
  }
  
  // Métodos para plazos
  async createTerm(data: InsertTerm): Promise<Term> {
    const id = this.termCurrentId++;
    const now = new Date();
    
    const term: Term = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    
    this.terms.set(id, term);
    return term;
  }
  
  async getTerm(id: number): Promise<Term | undefined> {
    return this.terms.get(id);
  }
  
  async getAllTerms(): Promise<Term[]> {
    return Array.from(this.terms.values());
  }
  
  async updateTerm(id: number, data: Partial<Term>): Promise<Term | undefined> {
    const term = this.terms.get(id);
    if (!term) return undefined;
    
    const { id: termId, createdAt, ...allowedUpdates } = data;
    
    const updatedTerm = {
      ...term,
      ...allowedUpdates,
      updatedAt: new Date()
    };
    
    this.terms.set(id, updatedTerm);
    return updatedTerm;
  }
  
  async deleteTerm(id: number): Promise<boolean> {
    return this.terms.delete(id);
  }
  
  // Métodos para conceptos
  async createConcept(data: InsertConcept): Promise<Concept> {
    const id = this.conceptCurrentId++;
    const now = new Date();
    
    const concept: Concept = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    
    this.concepts.set(id, concept);
    return concept;
  }
  
  async getConcept(id: number): Promise<Concept | undefined> {
    return this.concepts.get(id);
  }
  
  async getAllConcepts(): Promise<Concept[]> {
    return Array.from(this.concepts.values());
  }
  
  async updateConcept(id: number, data: Partial<Concept>): Promise<Concept | undefined> {
    const concept = this.concepts.get(id);
    if (!concept) return undefined;
    
    const { id: conceptId, createdAt, ...allowedUpdates } = data;
    
    const updatedConcept = {
      ...concept,
      ...allowedUpdates,
      updatedAt: new Date()
    };
    
    this.concepts.set(id, updatedConcept);
    return updatedConcept;
  }
  
  async deleteConcept(id: number): Promise<boolean> {
    return this.concepts.delete(id);
  }
  
  // Métodos para consultas
  async createQuery(data: InsertQuery): Promise<Query> {
    const id = this.queryCurrentId++;
    const now = new Date();
    
    // Agregar fecha de expiración (5 días a partir de ahora)
    const fiveDaysFromNow = new Date();
    fiveDaysFromNow.setDate(fiveDaysFromNow.getDate() + 5);
    
    const query: Query = {
      ...data,
      id,
      createdAt: now,
      expiresAt: fiveDaysFromNow,
    };
    
    this.queries.set(id, query);
    return query;
  }
  
  async getQuery(id: number): Promise<Query | undefined> {
    const query = this.queries.get(id);
    
    // Verificar si la consulta ha caducado
    if (query && query.expiresAt && new Date() > new Date(query.expiresAt)) {
      this.queries.delete(id);
      return undefined;
    }
    
    return query;
  }
  
  async getQueriesByUser(userId: number, limit?: number): Promise<Query[]> {
    // Obtener todas las consultas del usuario
    const userQueries = Array.from(this.queries.values())
      .filter(query => query.userId === userId);
    
    // Filtrar consultas expiradas
    const now = new Date();
    const validQueries = userQueries.filter(query => 
      !query.expiresAt || new Date(query.expiresAt) > now
    );
    
    // Ordenar por fecha de creación (las más recientes primero)
    validQueries.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    // Aplicar límite si está especificado
    return limit ? validQueries.slice(0, limit) : validQueries;
  }
  
  async getAllQueries(): Promise<Query[]> {
    // Filtrar consultas expiradas
    const now = new Date();
    return Array.from(this.queries.values())
      .filter(query => !query.expiresAt || new Date(query.expiresAt) > now);
  }
  
  async deleteQuery(id: number): Promise<boolean> {
    return this.queries.delete(id);
  }
  
  async deleteExpiredQueries(): Promise<number> {
    const now = new Date();
    let count = 0;
    
    // Eliminar todas las consultas expiradas
    for (const [id, query] of this.queries.entries()) {
      if (query.expiresAt && new Date(query.expiresAt) <= now) {
        this.queries.delete(id);
        count++;
      }
    }
    
    return count;
  }
  
  // Método para inicializar datos de ejemplo
  private async setUpSampleData() {
    try {
      // Limpiar datos existentes
      this.interestRates.clear();
      this.terms.clear();
      this.concepts.clear();
      this.interestRateCurrentId = 1;
      this.termCurrentId = 1;
      this.conceptCurrentId = 1;
      
      // Tasas de interés según especificaciones
      await this.createInterestRate({
        name: "12 meses",
        rate: "13",
        description: "Tasa de interés para financiamiento a 12 meses (13% EA)",
        createdBy: 1 // ID del administrador
      });
      
      await this.createInterestRate({
        name: "24 meses",
        rate: "14",
        description: "Tasa de interés para financiamiento a 24 meses (14% EA)",
        createdBy: 1
      });
      
      await this.createInterestRate({
        name: "36 meses",
        rate: "15",
        description: "Tasa de interés para financiamiento a 36 meses (15% EA)",
        createdBy: 1
      });
      
      await this.createInterestRate({
        name: "48 meses",
        rate: "16",
        description: "Tasa de interés para financiamiento a 48 meses (16% EA)",
        createdBy: 1
      });
      
      // Plazos según especificaciones
      await this.createTerm({
        name: "12 meses",
        months: 12,
        description: "Plazo de 12 meses (1 año)",
        createdBy: 1
      });
      
      await this.createTerm({
        name: "24 meses",
        months: 24,
        description: "Plazo de 24 meses (2 años)",
        createdBy: 1
      });
      
      await this.createTerm({
        name: "36 meses",
        months: 36,
        description: "Plazo de 36 meses (3 años)",
        createdBy: 1
      });
      
      await this.createTerm({
        name: "48 meses",
        months: 48,
        description: "Plazo de 48 meses (4 años)",
        createdBy: 1
      });
      
      // Conceptos (bolsas de horas e implementación) según especificaciones
      await this.createConcept({
        name: "Bolsa 30h",
        description: "Bolsa de 30 horas de soporte",
        category: "bolsa-horas",
        value: 500000,
        createdBy: 1
      });
      
      await this.createConcept({
        name: "Bolsa 70h",
        description: "Bolsa de 70 horas de soporte",
        category: "bolsa-horas",
        value: 1000000,
        createdBy: 1
      });
      
      await this.createConcept({
        name: "Bolsa 80h",
        description: "Bolsa de 80 horas de soporte",
        category: "bolsa-horas",
        value: 1500000,
        createdBy: 1
      });
      
      await this.createConcept({
        name: "Bolsa 100h",
        description: "Bolsa de 100 horas de soporte",
        category: "bolsa-horas",
        value: 2000000,
        createdBy: 1
      });
      
      await this.createConcept({
        name: "Implementación",
        description: "Implementación de las licencias adquiridas",
        category: "implementacion",
        value: 2800000,
        createdBy: 1
      });
      
      console.log("Datos de ejemplo creados con éxito");
    } catch (error) {
      console.error("Error al crear datos de ejemplo:", error);
    }
  }
}

export const storage = new MemStorage();
