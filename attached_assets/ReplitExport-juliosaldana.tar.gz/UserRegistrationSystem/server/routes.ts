import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertInterestRateSchema, 
  insertTermSchema, 
  insertConceptSchema, 
  insertQuerySchema
} from "@shared/schema";

// Middleware para verificar si el usuario es administrador
function isAdmin(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "No autenticado" });
  }
  
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: "Acceso denegado. Se requieren permisos de administrador." });
  }
  
  next();
}

// Middleware para verificar si el usuario está autenticado
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "No autenticado" });
  }
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  try {
    // Set up authentication routes
    setupAuth(app);

    // Ruta para actualizar perfil de usuario
    app.put("/api/user/profile", isAuthenticated, async (req, res) => {
      try {
        const updatedUser = await storage.updateUser(req.user.id, req.body);
        if (!updatedUser) {
          return res.status(404).json({ message: "Usuario no encontrado" });
        }
        
        const { password, ...userResponse } = updatedUser;
        res.json(userResponse);
      } catch (error) {
        console.error("Error al actualizar el perfil:", error);
        res.status(500).json({ message: "Error al actualizar el perfil" });
      }
    });

    // --------- RUTAS PARA ADMINISTRACIÓN (ADMIN) ---------
    
    // API de gestión de usuarios (solo admin)
    app.put("/api/admin/users/:id", isAdmin, async (req, res) => {
      try {
        const userId = parseInt(req.params.id);
        const updatedUser = await storage.updateUser(userId, req.body);
        
        if (!updatedUser) {
          return res.status(404).json({ message: "Usuario no encontrado" });
        }
        
        const { password, ...userResponse } = updatedUser;
        res.json(userResponse);
      } catch (error) {
        console.error("Error al actualizar el usuario:", error);
        res.status(500).json({ message: "Error al actualizar el usuario" });
      }
    });
    
    app.delete("/api/admin/users/:id", isAdmin, async (req, res) => {
      try {
        const userId = parseInt(req.params.id);
        
        // No permitir que un usuario elimine su propia cuenta
        if (userId === req.user.id) {
          return res.status(400).json({ message: "No puede eliminar su propia cuenta" });
        }
        
        const result = await storage.deleteUser(userId);
        
        if (!result) {
          return res.status(404).json({ message: "Usuario no encontrado o es un administrador" });
        }
        
        res.status(204).end();
      } catch (error) {
        console.error("Error al eliminar el usuario:", error);
        res.status(500).json({ message: "Error al eliminar el usuario" });
      }
    });
    
    // --------- TASAS DE INTERÉS ---------
    
    // Obtener todas las tasas
    app.get("/api/interest-rates", async (req, res) => {
      try {
        const rates = await storage.getAllInterestRates();
        res.json(rates);
      } catch (error) {
        console.error("Error al obtener tasas de interés:", error);
        res.status(500).json({ message: "Error al obtener tasas de interés" });
      }
    });
    
    // Obtener una tasa específica
    app.get("/api/interest-rates/:id", async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const rate = await storage.getInterestRate(id);
        
        if (!rate) {
          return res.status(404).json({ message: "Tasa de interés no encontrada" });
        }
        
        res.json(rate);
      } catch (error) {
        console.error("Error al obtener tasa de interés:", error);
        res.status(500).json({ message: "Error al obtener tasa de interés" });
      }
    });
    
    // Crear tasa (solo admin)
    app.post("/api/interest-rates", isAdmin, async (req, res) => {
      try {
        const data = insertInterestRateSchema.parse({
          ...req.body,
          createdBy: req.user.id
        });
        
        const rate = await storage.createInterestRate(data);
        res.status(201).json(rate);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
        }
        
        console.error("Error al crear tasa de interés:", error);
        res.status(500).json({ message: "Error al crear tasa de interés" });
      }
    });
    
    // Actualizar tasa (solo admin)
    app.put("/api/interest-rates/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const updatedRate = await storage.updateInterestRate(id, req.body);
        
        if (!updatedRate) {
          return res.status(404).json({ message: "Tasa de interés no encontrada" });
        }
        
        res.json(updatedRate);
      } catch (error) {
        console.error("Error al actualizar tasa de interés:", error);
        res.status(500).json({ message: "Error al actualizar tasa de interés" });
      }
    });
    
    // Eliminar tasa (solo admin)
    app.delete("/api/interest-rates/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const result = await storage.deleteInterestRate(id);
        
        if (!result) {
          return res.status(404).json({ message: "Tasa de interés no encontrada" });
        }
        
        res.status(204).end();
      } catch (error) {
        console.error("Error al eliminar tasa de interés:", error);
        res.status(500).json({ message: "Error al eliminar tasa de interés" });
      }
    });
    
    // --------- PLAZOS ---------
    
    // Obtener todos los plazos
    app.get("/api/terms", async (req, res) => {
      try {
        const terms = await storage.getAllTerms();
        res.json(terms);
      } catch (error) {
        console.error("Error al obtener plazos:", error);
        res.status(500).json({ message: "Error al obtener plazos" });
      }
    });
    
    // Obtener un plazo específico
    app.get("/api/terms/:id", async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const term = await storage.getTerm(id);
        
        if (!term) {
          return res.status(404).json({ message: "Plazo no encontrado" });
        }
        
        res.json(term);
      } catch (error) {
        console.error("Error al obtener plazo:", error);
        res.status(500).json({ message: "Error al obtener plazo" });
      }
    });
    
    // Crear plazo (solo admin)
    app.post("/api/terms", isAdmin, async (req, res) => {
      try {
        const data = insertTermSchema.parse({
          ...req.body,
          createdBy: req.user.id
        });
        
        const term = await storage.createTerm(data);
        res.status(201).json(term);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
        }
        
        console.error("Error al crear plazo:", error);
        res.status(500).json({ message: "Error al crear plazo" });
      }
    });
    
    // Actualizar plazo (solo admin)
    app.put("/api/terms/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const updatedTerm = await storage.updateTerm(id, req.body);
        
        if (!updatedTerm) {
          return res.status(404).json({ message: "Plazo no encontrado" });
        }
        
        res.json(updatedTerm);
      } catch (error) {
        console.error("Error al actualizar plazo:", error);
        res.status(500).json({ message: "Error al actualizar plazo" });
      }
    });
    
    // Eliminar plazo (solo admin)
    app.delete("/api/terms/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const result = await storage.deleteTerm(id);
        
        if (!result) {
          return res.status(404).json({ message: "Plazo no encontrado" });
        }
        
        res.status(204).end();
      } catch (error) {
        console.error("Error al eliminar plazo:", error);
        res.status(500).json({ message: "Error al eliminar plazo" });
      }
    });
    
    // --------- CONCEPTOS ---------
    
    // Obtener todos los conceptos
    app.get("/api/concepts", async (req, res) => {
      try {
        const concepts = await storage.getAllConcepts();
        res.json(concepts);
      } catch (error) {
        console.error("Error al obtener conceptos:", error);
        res.status(500).json({ message: "Error al obtener conceptos" });
      }
    });
    
    // Obtener un concepto específico
    app.get("/api/concepts/:id", async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const concept = await storage.getConcept(id);
        
        if (!concept) {
          return res.status(404).json({ message: "Concepto no encontrado" });
        }
        
        res.json(concept);
      } catch (error) {
        console.error("Error al obtener concepto:", error);
        res.status(500).json({ message: "Error al obtener concepto" });
      }
    });
    
    // Crear concepto (solo admin)
    app.post("/api/concepts", isAdmin, async (req, res) => {
      try {
        const data = insertConceptSchema.parse({
          ...req.body,
          createdBy: req.user.id
        });
        
        const concept = await storage.createConcept(data);
        res.status(201).json(concept);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
        }
        
        console.error("Error al crear concepto:", error);
        res.status(500).json({ message: "Error al crear concepto" });
      }
    });
    
    // Actualizar concepto (solo admin)
    app.put("/api/concepts/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const updatedConcept = await storage.updateConcept(id, req.body);
        
        if (!updatedConcept) {
          return res.status(404).json({ message: "Concepto no encontrado" });
        }
        
        res.json(updatedConcept);
      } catch (error) {
        console.error("Error al actualizar concepto:", error);
        res.status(500).json({ message: "Error al actualizar concepto" });
      }
    });
    
    // Eliminar concepto (solo admin)
    app.delete("/api/concepts/:id", isAdmin, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        const result = await storage.deleteConcept(id);
        
        if (!result) {
          return res.status(404).json({ message: "Concepto no encontrado" });
        }
        
        res.status(204).end();
      } catch (error) {
        console.error("Error al eliminar concepto:", error);
        res.status(500).json({ message: "Error al eliminar concepto" });
      }
    });
    
    // --------- CONSULTAS ---------
    
    // Realizar una consulta
    app.post("/api/queries", isAuthenticated, async (req, res) => {
      try {
        const data = insertQuerySchema.parse({
          ...req.body,
          userId: req.user.id
        });
        
        // Calcular resultado basado en parámetros
        const calculatedResults = calculateQueryResults(data.parameters);
        
        // Almacenar consulta con resultados
        const query = await storage.createQuery({
          ...data,
          results: calculatedResults
        });
        
        res.status(201).json(query);
      } catch (error) {
        if (error instanceof z.ZodError) {
          return res.status(400).json({ message: "Datos inválidos", errors: error.errors });
        }
        
        console.error("Error al crear consulta:", error);
        res.status(500).json({ message: "Error al crear consulta" });
      }
    });
    
    // Obtener consultas del usuario actual
    app.get("/api/queries", isAuthenticated, async (req, res) => {
      try {
        // Obtener las 5 consultas más recientes
        const queries = await storage.getQueriesByUser(req.user.id, 5);
        res.json(queries);
      } catch (error) {
        console.error("Error al obtener consultas:", error);
        res.status(500).json({ message: "Error al obtener consultas" });
      }
    });
    
    // API para consulta de licencias especial
    app.post("/api/license-query", isAuthenticated, async (req, res) => {
      try {
        const { queryType, parameters } = req.body;
        const userId = req.user.id;
        
        // Validar parámetros
        if (!parameters || !parameters.licenseQuantity || !parameters.licenseUnitPrice) {
          return res.status(400).json({ message: "Faltan parámetros requeridos" });
        }
        
        // Obtener los parámetros
        const licenseQuantity = parseInt(parameters.licenseQuantity);
        const licenseUnitPrice = parseFloat(parameters.licenseUnitPrice);
        // Usar valores fijos para estos parámetros
        const implementationCost = 2800000; // Costo fijo de implementación
        
        // Calcular el costo total de las licencias
        const totalLicenseCost = licenseQuantity * licenseUnitPrice;
        
        // Obtener todos los conceptos (bolsas de horas)
        const allConcepts = await storage.getAllConcepts();
        
        // Filtrar conceptos por categoría
        const hourPackageOptions = allConcepts.filter(concept => 
          concept.category === "bolsa-horas"
        );
        
        // Si no hay conceptos definidos, crear las bolsas de horas predeterminadas
        if (!hourPackageOptions || hourPackageOptions.length === 0) {
          // Crear bolsas de horas predeterminadas
          const defaultPackages = [
            { name: "30 horas", description: "Bolsa de 30 horas", category: "bolsa-horas", priceValue: 500000 },
            { name: "70 horas", description: "Bolsa de 70 horas", category: "bolsa-horas", priceValue: 1000000 },
            { name: "80 horas", description: "Bolsa de 80 horas", category: "bolsa-horas", priceValue: 1500000 },
            { name: "100 horas", description: "Bolsa de 100 horas", category: "bolsa-horas", priceValue: 2000000 },
            { name: "Implementación", description: "Implementación de licencias", category: "bolsa-horas", priceValue: 2800000 }
          ];
          
          for (const pkg of defaultPackages) {
            await storage.createConcept({
              name: pkg.name,
              description: pkg.description,
              category: pkg.category
            });
          }
        }
        
        // Volver a obtener los conceptos actualizados
        const updatedConcepts = await storage.getAllConcepts();
        const hourPackages = updatedConcepts.filter(concept => 
          concept.category === "bolsa-horas"
        );
        
        // Ya no necesitamos este mapa de precios, está duplicado
        
        // Seleccionar implementación y una bolsa de horas según el monto de licencias
        let implementationPackage = null;
        let hourPackage = null;
        
        // Buscar implementación
        implementationPackage = hourPackages.find(pkg => 
          pkg.name.toLowerCase().includes("implementación") || pkg.description?.toLowerCase().includes("implementación")
        );
        
        // Seleccionar bolsa de horas adecuada según el monto
        if (totalLicenseCost >= 1500000) {
          hourPackage = hourPackages.find(pkg => pkg.name.includes("100"));
        } else if (totalLicenseCost >= 1000000) {
          hourPackage = hourPackages.find(pkg => pkg.name.includes("80"));
        } else if (totalLicenseCost >= 500000) {
          hourPackage = hourPackages.find(pkg => pkg.name.includes("70"));
        } else {
          hourPackage = hourPackages.find(pkg => pkg.name.includes("30"));
        }
        
        // Si no se encuentra alguno, usar el primero disponible
        if (!implementationPackage && hourPackages.length > 0) {
          implementationPackage = hourPackages.find(pkg => 
            pkg.name.toLowerCase().includes("implementación") || pkg.description?.toLowerCase().includes("implementación")
          );
        }
        
        if (!hourPackage && hourPackages.length > 0) {
          hourPackage = hourPackages.find(pkg => 
            !pkg.name.toLowerCase().includes("implementación") && 
            !pkg.description?.toLowerCase().includes("implementación")
          );
        }
        
        // Mapa de precios predeterminados para las bolsas de horas
        const defaultPrices: Record<string, number> = {
          "30 horas": 500000,
          "70 horas": 1000000,
          "80 horas": 1500000,
          "100 horas": 2000000,
          "Implementación": 2800000
        };
        
        // Determinar costos usando los precios predeterminados
        let implementationCostValue = 2800000; // Valor fijo para implementación
        
        const hourPackageCost = hourPackage ? 
          (hourPackage.name.includes("30") ? 500000 :
           hourPackage.name.includes("70") ? 1000000 :
           hourPackage.name.includes("80") ? 1500000 :
           hourPackage.name.includes("100") ? 2000000 : 0) : 0;
        
        // Obtener todos los plazos
        const terms = await storage.getAllTerms();
        
        // Obtener todas las tasas
        const interestRates = await storage.getAllInterestRates();
        
        // Calcular opciones de financiamiento para cada plazo y concepto
        const financingOptions = [];
        
        for (const term of terms) {
          // Determinar tasa de interés según el plazo
          let interestRate;
          
          // Asignar tasas según el requerimiento específico
          if (term.months === 12) interestRate = 0.13;      // 13% EA para 12 meses
          else if (term.months === 24) interestRate = 0.14; // 14% EA para 24 meses
          else if (term.months === 36) interestRate = 0.15; // 15% EA para 36 meses
          else if (term.months === 48) interestRate = 0.16; // 16% EA para 48 meses
          else interestRate = 0.15; // Tasa por defecto
          
          // Calcular financiamiento para licencias
          const licenseTotalAmount = calculateFinancingAmount(totalLicenseCost, interestRate, term.months);
          financingOptions.push({
            termId: term.id,
            term: {
              id: term.id,
              name: term.name,
              months: term.months,
              description: term.description
            },
            interestRate: interestRate * 100,
            concept: "Licencias",
            baseAmount: totalLicenseCost,
            totalAmount: licenseTotalAmount,
            monthlyPayment: licenseTotalAmount / term.months
          });
          
          // Calcular financiamiento para bolsa de horas (si existe)
          if (hourPackage) {
            const hoursTotalAmount = calculateFinancingAmount(hourPackageCost, interestRate, term.months);
            financingOptions.push({
              termId: term.id,
              term: {
                id: term.id,
                name: term.name,
                months: term.months,
                description: term.description
              },
              interestRate: interestRate * 100,
              concept: "Bolsa de Horas",
              baseAmount: hourPackageCost,
              totalAmount: hoursTotalAmount,
              monthlyPayment: hoursTotalAmount / term.months
            });
          }
          
          // Calcular financiamiento para implementación (si existe)
          if (implementationPackage) {
            const implementationTotalAmount = calculateFinancingAmount(implementationCostValue, interestRate, term.months);
            financingOptions.push({
              termId: term.id,
              term: {
                id: term.id,
                name: term.name,
                months: term.months,
                description: term.description
              },
              interestRate: interestRate * 100,
              concept: "Implementación",
              baseAmount: implementationCostValue,
              totalAmount: implementationTotalAmount,
              monthlyPayment: implementationTotalAmount / term.months
            });
          }
        }
        
        // Preparar resultados
        const results = {
          licenseQuantity,
          licenseUnitPrice,
          totalLicenseCost,
          implementationPackage,
          implementationCost: implementationCostValue,
          hourPackage,
          hourPackageCost,
          hourPackages: hourPackages || [],
          totalCost: totalLicenseCost + implementationCostValue + hourPackageCost,
          financingOptions
        };
        
        // Crear la consulta en la base de datos
        const query = await storage.createQuery({
          userId,
          queryType: "license-calculation",
          parameters,
          results
        });
        
        // Devolver los resultados asegurando que sea un objeto JSON válido
        res.setHeader('Content-Type', 'application/json');
        res.status(200).json(results);
      } catch (error: any) {
        console.error("Error en API license-query:", error);
        res.status(500).json({ message: error.message || "Error al procesar consulta de licencias" });
      }
    });
    
    // Eliminar una consulta del usuario
    app.delete("/api/queries/:id", isAuthenticated, async (req, res) => {
      try {
        const id = parseInt(req.params.id);
        
        // Verificar que la consulta pertenece al usuario
        const query = await storage.getQuery(id);
        if (!query) {
          return res.status(404).json({ message: "Consulta no encontrada" });
        }
        
        if (query.userId !== req.user.id && req.user.role !== 'admin') {
          return res.status(403).json({ message: "No autorizado para eliminar esta consulta" });
        }
        
        const result = await storage.deleteQuery(id);
        
        if (!result) {
          return res.status(404).json({ message: "Consulta no encontrada" });
        }
        
        res.status(204).end();
      } catch (error) {
        console.error("Error al eliminar consulta:", error);
        res.status(500).json({ message: "Error al eliminar consulta" });
      }
    });
    
    // Obtener todas las consultas (solo admin)
    app.get("/api/admin/queries", isAdmin, async (req, res) => {
      try {
        const queries = await storage.getAllQueries();
        res.json(queries);
      } catch (error) {
        console.error("Error al obtener todas las consultas:", error);
        res.status(500).json({ message: "Error al obtener todas las consultas" });
      }
    });
    
    // Eliminar consultas expiradas (solo admin)
    app.delete("/api/admin/queries/expired", isAdmin, async (req, res) => {
      try {
        const count = await storage.deleteExpiredQueries();
        res.json({ message: `${count} consultas expiradas eliminadas` });
      } catch (error) {
        console.error("Error al eliminar consultas expiradas:", error);
        res.status(500).json({ message: "Error al eliminar consultas expiradas" });
      }
    });
    
    // Crear el servidor HTTP
    const httpServer = createServer(app);
    return httpServer;
  } catch (error) {
    console.error("Error en configuración de rutas:", error);
    throw error;
  }
}

// Función para calcular los resultados de una consulta
function calculateQueryResults(parameters: any): any {
  try {
    // Aquí iría la lógica específica para calcular resultados
    // basada en los parámetros proporcionados
    // Este es un ejemplo sencillo
    
    const { monto = 0, plazoMeses = 0, tasaInteres = 0, tipo = 'simple', ...otrosParametros } = parameters;
    
    // Convertir valores a números si son strings
    const montoValue = typeof monto === 'string' ? parseFloat(monto) : monto;
    const plazoValue = typeof plazoMeses === 'string' ? parseInt(plazoMeses) : plazoMeses;
    const tasaValue = typeof tasaInteres === 'string' ? parseFloat(tasaInteres) : tasaInteres;
    
    let resultado;
    
    if (tipo === 'simple') {
      // Interés simple: I = P * r * t
      // Donde P es el monto, r es la tasa de interés anual, t es el tiempo en años
      const tasaDecimal = tasaValue / 100;
      const tiempoAnios = plazoValue / 12;
      const interes = montoValue * tasaDecimal * tiempoAnios;
      const montoTotal = montoValue + interes;
      
      resultado = {
        montoInicial: montoValue,
        interes,
        montoTotal,
        pagoMensual: montoTotal / plazoValue,
        detalles: generarDetallesPagos(montoValue, tasaDecimal, plazoValue)
      };
    } else if (tipo === 'compuesto') {
      // Interés compuesto: A = P(1 + r)^t
      // Donde A es el monto final, P es el monto inicial, r es la tasa, t es el tiempo
      const tasaDecimal = tasaValue / 100;
      const tiempoAnios = plazoValue / 12;
      const montoTotal = montoValue * Math.pow(1 + tasaDecimal, tiempoAnios);
      const interes = montoTotal - montoValue;
      
      resultado = {
        montoInicial: montoValue,
        interes,
        montoTotal,
        pagoMensual: montoTotal / plazoValue,
        detalles: generarDetallesPagos(montoValue, tasaDecimal, plazoValue, true)
      };
    } else {
      resultado = {
        error: "Tipo de cálculo no soportado"
      };
    }
    
    // Incluir la fecha y hora de cálculo
    resultado.fechaCalculo = new Date().toISOString();
    
    // Incluir los parámetros originales para referencia
    resultado.parametros = parameters;
    
    return resultado;
  } catch (error) {
    console.error("Error al calcular resultados:", error);
    return { error: "Error en el cálculo", message: error.message };
  }
}

// Función para calcular el monto financiado
function calculateFinancingAmount(baseAmount: number, interestRate: number, months: number): number {
  // Fórmula simple de interés compuesto
  const effectiveRate = Math.pow(1 + interestRate, months / 12) - 1;
  return baseAmount * (1 + effectiveRate);
}

// Función auxiliar para generar detalles de pagos
function generarDetallesPagos(
  monto: number, 
  tasaAnual: number, 
  plazoMeses: number, 
  esCompuesto: boolean = false
): Array<{
  mes: number;
  pagoCapital: number;
  pagoInteres: number;
  pagoTotal: number;
  saldoRestante: number;
}> {
  const pagos = [];
  const tasaMensual = tasaAnual / 12;
  
  let saldoRestante = monto;
  
  if (esCompuesto) {
    // Para interés compuesto con pagos mensuales usamos la fórmula de amortización
    // PMT = P * r * (1 + r)^n / ((1 + r)^n - 1)
    const tasaDecimal = tasaMensual;
    const pagoMensual = monto * tasaDecimal * Math.pow(1 + tasaDecimal, plazoMeses) / 
                       (Math.pow(1 + tasaDecimal, plazoMeses) - 1);
    
    for (let mes = 1; mes <= plazoMeses; mes++) {
      const pagoInteres = saldoRestante * tasaDecimal;
      const pagoCapital = pagoMensual - pagoInteres;
      saldoRestante -= pagoCapital;
      
      // Ajustar el último pago para que el saldo sea exactamente cero
      if (mes === plazoMeses) {
        pagos.push({
          mes,
          pagoCapital: pagoCapital + saldoRestante,
          pagoInteres,
          pagoTotal: pagoCapital + pagoInteres + saldoRestante,
          saldoRestante: 0
        });
      } else {
        pagos.push({
          mes,
          pagoCapital,
          pagoInteres,
          pagoTotal: pagoMensual,
          saldoRestante
        });
      }
    }
  } else {
    // Para interés simple
    const pagoCapitalMensual = monto / plazoMeses;
    
    for (let mes = 1; mes <= plazoMeses; mes++) {
      const pagoInteres = saldoRestante * tasaMensual;
      saldoRestante -= pagoCapitalMensual;
      
      pagos.push({
        mes,
        pagoCapital: pagoCapitalMensual,
        pagoInteres,
        pagoTotal: pagoCapitalMensual + pagoInteres,
        saldoRestante: Math.max(0, saldoRestante) // Evitar saldos negativos por redondeo
      });
    }
  }
  
  return pagos;
}
